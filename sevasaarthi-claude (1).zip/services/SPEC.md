# SevaSaarthi — 24-Hour Hackathon MVP
**Tagline:** "Government services, made simple."

## What It Is
An AI-powered, multilingual, accessible citizen-service navigator. A citizen types/speaks a need in natural language; the app maps it to relevant services from a structured knowledge base, guides eligibility, builds a document checklist, runs a guided application, and tracks status. The citizen JOURNEY is the product; AI is just the intelligence layer.

## Stack
- React + TypeScript + Vite + Tailwind CSS
- Lucide React (icons)
- Recharts (for analytics/charts)
- Browser Web Speech API for voice (STT & TTS)
- Phase 1: Local JSON + localStorage (No backend yet; Supabase and LLM later)

## Hard Rules
- Never invent schemes. All services come from `/src/data/services.json` and are labeled "Demo data".
- If info is missing, say "Information not available".
- Eligibility is preliminary: show "This is preliminary guidance. Final eligibility is decided by the concerned authority."
- No real Aadhaar/payment/government APIs. Clearly label simulated features ("Demo").
- No API keys in frontend. Use fictional citizen data only.
- Don't fabricate impact statistics; label any numbers "simulated demo data".
- Mobile-first, accessible (semantic HTML, ARIA, visible focus, large touch targets, don't rely on color alone).
- Friendly, modern, card-based UI. NOT an admin-dashboard look. Progressive disclosure: never show everything at once.
- Keep code simple. Don't over-engineer. Prefer fewer, polished screens over many features.

## Citizen Flow
1. **Home:** "How can we help you today?" Hero feature "🎤 Just tell me what you need" (subtext: "No need to know the department or scheme name"). Text box, mic button, Search, "Track my application". Category cards: Education, Housing, Financial Assistance, Senior Citizens, Disability Services, Farmer Services, Certificates. Language switch EN | తెలుగు | हिंदी. Accessibility button. Data Saver toggle.
2. **Discovery:** From user's text, detect intent/category/language → "We understood you need: 🎓 Education Assistance" → 2–3 service cards with "Why this matches you", department, eligibility summary, required docs, application method, processing info. Button: "Check my eligibility".
3. **Eligibility Wizard:** "Who are you?" (Student/Farmer/Senior/Woman/Person with Disability/Other) → ask ONLY 3–4 relevant questions (age, state, occupation/education, approx income) → result with 🟢 matched / 🟡 needs verification / 🔴 not met (with icons + text labels, not just color).
4. **Document Checklist:** Service-specific; each doc has required/optional label, upload button (mock upload, store filename), status.
5. **Guided Application:** 4 steps with progress bar: Personal Details → Eligibility → Documents → Review & Submit. Short "why we ask this" helper text per step.
6. **Submission:** "Application Submitted 🎉", ID like SV-2026-001247, date, service, department, status, next stage. Button: Track Application.
7. **Tracking:** Vertical timeline (Submitted → Documents Received → Department Review → Decision → Completed) with timestamps and plain-language explanations (no jargon).
8. **Floating AI Assistant:** On every citizen screen: answers "what documents do I need?", "am I eligible?", "why this document?", "what happens next?", "explain in Telugu". Rule/keyword-based answers behind an `askAssistant()` function.

## Cross-Cutting
- **i18n:** EN / TE / HI via translation dictionaries + LanguageContext. Demo services have translated fields.
- **Voice:** Web Speech API (speech-to-text) with fallback. "🔊 Read Aloud" (speechSynthesis).
- **Accessibility Panel:** Text size (normal/large/xlarge), high contrast, reduce motion, simplified UI, read aloud toggle, keyboard focus styling. Persisted in localStorage.
- **Data Saver Mode:** No animations, text-first, minimal decoration. Persisted in localStorage.

## Secondary Screens
- **/admin:** Metrics (Total Citizens, Applications, Pending, Completed, AI Journeys, A11y Usage), application list, detail view with status update & notification trigger.
- **/analytics:** Demo metrics and charts for service, language, a11y, funnel, common queries.

## Demo Persona
- **Anitha**, 20, Telugu, student, needs education financial help.
- End-to-end journey must work seamlessly: Telugu language → speak need → service found → wizard → checklist → upload → submit → track → admin update → citizen notification.
