import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { LanguageProvider } from './context/LanguageContext';
import { AccessibilityProvider } from './context/AccessibilityContext';
import { DemoNoticeBanner } from './components/DemoNoticeBanner';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

// Pages
import { HomePage } from './pages/HomePage';
import { DiscoveryPage } from './pages/DiscoveryPage';
import { EligibilityWizardPage } from './pages/EligibilityWizardPage';
import { DocumentChecklistPage } from './pages/DocumentChecklistPage';
import { GuidedApplicationPage } from './pages/GuidedApplicationPage';
import { SubmissionSuccessPage } from './pages/SubmissionSuccessPage';
import { TrackingPage } from './pages/TrackingPage';
import { AdminPage } from './pages/AdminPage';
import { AnalyticsPage } from './pages/AnalyticsPage';

export const App: React.FC = () => {
  return (
    <LanguageProvider>
      <AccessibilityProvider>
        <BrowserRouter>
          <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-gray-950 text-slate-900 dark:text-slate-100 antialiased transition-colors">
            {/* Skip link for screen readers */}
            <a
              href="#main-content"
              className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:px-4 focus:py-2 focus:bg-blue-600 focus:text-white focus:rounded-lg focus:shadow-lg"
            >
              Skip to main content
            </a>

            {/* Demonstration Notice */}
            <DemoNoticeBanner />

            {/* Navigation Bar */}
            <Navbar />

            {/* Main Application Routes */}
            <div className="flex-1 flex flex-col">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/discovery" element={<DiscoveryPage />} />
                <Route path="/wizard/:serviceId" element={<EligibilityWizardPage />} />
                <Route path="/checklist/:serviceId" element={<DocumentChecklistPage />} />
                <Route path="/apply/:serviceId" element={<GuidedApplicationPage />} />
                <Route path="/submission/:id" element={<SubmissionSuccessPage />} />
                <Route path="/track" element={<TrackingPage />} />
                <Route path="/admin" element={<AdminPage />} />
                <Route path="/analytics" element={<AnalyticsPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </div>

            {/* Footer */}
            <Footer />
          </div>
        </BrowserRouter>
      </AccessibilityProvider>
    </LanguageProvider>
  );
};

export default App;
