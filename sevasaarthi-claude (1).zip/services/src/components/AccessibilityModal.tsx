import React, { useEffect, useRef } from 'react';
import {
  X,
  RotateCcw,
  Eye,
  Type,
  Sparkles,
  Volume2,
  Database,
  ZapOff,
  Keyboard,
  Check,
} from 'lucide-react';
import { useAccessibility } from '../context/AccessibilityContext';
import { useLanguage } from '../context/LanguageContext';
import type { TextSize, ContrastMode } from '../types';

interface AccessibilityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AccessibilityModal: React.FC<AccessibilityModalProps> = ({ isOpen, onClose }) => {
  const {
    settings,
    setTextSize,
    setContrastMode,
    toggleReduceMotion,
    toggleSimplifiedInterface,
    toggleReadAloud,
    toggleDataSaver,
    resetSettings,
    speakText,
  } = useAccessibility();
  const { language, t } = useLanguage();
  const modalRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  // Focus trap & Escape key handler
  useEffect(() => {
    if (!isOpen) return;

    closeButtonRef.current?.focus();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="a11y-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={modalRef}
        className="w-full max-w-xl bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 rounded-3xl shadow-2xl border border-gray-200 dark:border-gray-700 overflow-hidden max-h-[90vh] flex flex-col"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-800 bg-gray-50/70 dark:bg-gray-800/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300">
              <Eye className="w-5 h-5" aria-hidden="true" />
            </div>
            <div>
              <h2 id="a11y-modal-title" className="text-lg font-bold">
                {t('a11y.modalTitle')}
              </h2>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {t('a11y.description')}
              </p>
            </div>
          </div>
          <button
            ref={closeButtonRef}
            onClick={onClose}
            aria-label={t('a11y.close')}
            className="p-2 text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Live Preview Card */}
          <div className="p-4 rounded-2xl border border-blue-200 dark:border-blue-900/60 bg-blue-50/40 dark:bg-blue-950/20 space-y-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 dark:text-blue-300">
              Live Appearance Preview
            </span>
            <p className="text-sm font-semibold text-gray-900 dark:text-white">
              "Government services, made simple for all citizens."
            </p>
            <p className="text-xs text-gray-600 dark:text-gray-300">
              This text scales with your text size and updates contrast settings immediately.
            </p>
          </div>

          {/* Text Size Section */}
          <div className="space-y-2">
            <label className="text-sm font-semibold flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Type className="w-4 h-4 text-blue-600 dark:text-blue-400" aria-hidden="true" />
                <span>{t('a11y.textSize')}</span>
              </span>
              <span className="text-xs text-blue-600 dark:text-blue-400 font-bold uppercase">
                {settings.textSize}
              </span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['normal', 'large', 'xlarge'] as TextSize[]).map((size) => {
                const isSelected = settings.textSize === size;
                const label =
                  size === 'normal'
                    ? t('a11y.textNormal')
                    : size === 'large'
                    ? t('a11y.textLarge')
                    : t('a11y.textXLarge');

                return (
                  <button
                    key={size}
                    type="button"
                    onClick={() => setTextSize(size)}
                    aria-pressed={isSelected}
                    className={`py-2.5 px-3 rounded-2xl border text-xs sm:text-sm font-semibold transition-all text-center touch-target flex flex-col items-center justify-center gap-1 ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50 text-blue-700 dark:bg-blue-950/70 dark:border-blue-500 dark:text-blue-300 ring-2 ring-blue-600/20'
                        : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 bg-white dark:bg-gray-800'
                    }`}
                  >
                    <span>{label}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" aria-hidden="true" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Contrast Mode Section */}
          <div className="space-y-2">
            <label className="text-sm font-semibold flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400" aria-hidden="true" />
                <span>{t('a11y.contrast')}</span>
              </span>
              <span className="text-xs text-blue-600 dark:text-blue-400 font-bold uppercase">
                {settings.contrastMode}
              </span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['default', 'high', 'dark'] as ContrastMode[]).map((mode) => {
                const isSelected = settings.contrastMode === mode;
                const label =
                  mode === 'default'
                    ? t('a11y.contrastDefault')
                    : mode === 'high'
                    ? t('a11y.contrastHigh')
                    : t('a11y.contrastDark');

                return (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => setContrastMode(mode)}
                    aria-pressed={isSelected}
                    className={`py-2.5 px-3 rounded-2xl border text-xs sm:text-sm font-semibold transition-all text-center touch-target flex flex-col items-center justify-center gap-1 ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50 text-blue-700 dark:bg-blue-950/70 dark:border-blue-500 dark:text-blue-300 ring-2 ring-blue-600/20'
                        : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 bg-white dark:bg-gray-800'
                    }`}
                  >
                    <span>{label}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" aria-hidden="true" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Toggles list */}
          <div className="space-y-3 pt-2">
            {/* Reduce Motion */}
            <div className="flex items-center justify-between p-3.5 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/40">
              <div className="flex items-start gap-3">
                <ZapOff className="w-5 h-5 text-gray-600 dark:text-gray-400 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-sm font-semibold">{t('a11y.motion')}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{t('a11y.motionDesc')}</p>
                </div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={settings.reduceMotion}
                onClick={toggleReduceMotion}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                  settings.reduceMotion ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                    settings.reduceMotion ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Read Aloud Default Enable */}
            <div className="flex items-center justify-between p-3.5 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/40">
              <div className="flex items-start gap-3">
                <Volume2 className="w-5 h-5 text-gray-600 dark:text-gray-400 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-sm font-semibold">{t('a11y.readAloud')}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{t('a11y.readAloudDesc')}</p>
                </div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={settings.readAloudEnabled}
                onClick={() => {
                  toggleReadAloud();
                  if (!settings.readAloudEnabled) {
                    speakText('Voice read aloud is now enabled', language);
                  }
                }}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                  settings.readAloudEnabled ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                    settings.readAloudEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Simplified Interface */}
            <div className="flex items-center justify-between p-3.5 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/40">
              <div className="flex items-start gap-3">
                <Eye className="w-5 h-5 text-gray-600 dark:text-gray-400 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-sm font-semibold">{t('a11y.simplified')}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{t('a11y.simplifiedDesc')}</p>
                </div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={settings.simplifiedInterface}
                onClick={toggleSimplifiedInterface}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                  settings.simplifiedInterface ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                    settings.simplifiedInterface ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Data Saver Mode */}
            <div className="flex items-center justify-between p-3.5 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/40">
              <div className="flex items-start gap-3">
                <Database className="w-5 h-5 text-gray-600 dark:text-gray-400 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-sm font-semibold">{t('a11y.dataSaver')}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{t('a11y.dataSaverDesc')}</p>
                </div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={settings.dataSaver}
                onClick={toggleDataSaver}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                  settings.dataSaver ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                    settings.dataSaver ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Keyboard Shortcuts Section */}
          <div className="p-4 rounded-2xl bg-gray-100 dark:bg-gray-800/80 border border-gray-200 dark:border-gray-700 space-y-2">
            <h3 className="text-xs font-bold text-gray-700 dark:text-gray-300 flex items-center gap-1.5 uppercase tracking-wider">
              <Keyboard className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Keyboard Quick Shortcuts</span>
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs text-gray-600 dark:text-gray-300">
              <div className="flex items-center justify-between p-1.5 bg-white dark:bg-gray-900 rounded-lg">
                <span>Accessibility Panel</span>
                <kbd className="px-1.5 py-0.5 bg-gray-100 dark:bg-gray-800 rounded border border-gray-300 dark:border-gray-600 text-[10px] font-mono">Alt + A</kbd>
              </div>
              <div className="flex items-center justify-between p-1.5 bg-white dark:bg-gray-900 rounded-lg">
                <span>Notifications</span>
                <kbd className="px-1.5 py-0.5 bg-gray-100 dark:bg-gray-800 rounded border border-gray-300 dark:border-gray-600 text-[10px] font-mono">Alt + N</kbd>
              </div>
              <div className="flex items-center justify-between p-1.5 bg-white dark:bg-gray-900 rounded-lg">
                <span>Close Dialog</span>
                <kbd className="px-1.5 py-0.5 bg-gray-100 dark:bg-gray-800 rounded border border-gray-300 dark:border-gray-600 text-[10px] font-mono">Esc</kbd>
              </div>
              <div className="flex items-center justify-between p-1.5 bg-white dark:bg-gray-900 rounded-lg">
                <span>Next Element</span>
                <kbd className="px-1.5 py-0.5 bg-gray-100 dark:bg-gray-800 rounded border border-gray-300 dark:border-gray-600 text-[10px] font-mono">Tab</kbd>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/50">
          <button
            type="button"
            onClick={resetSettings}
            className="flex items-center gap-1.5 text-xs font-semibold text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{t('a11y.reset')}</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-sm transition-colors"
          >
            {t('a11y.close')}
          </button>
        </div>
      </div>
    </div>
  );
};
