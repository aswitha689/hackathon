import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  GraduationCap,
  Home as HomeIcon,
  Banknote,
  HeartHandshake,
  Accessibility,
  Tractor,
  FileCheck2,
  ArrowUpRight,
  type LucideIcon,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import rawServices from '../data/services.json';
import type { Service, ServiceCategory } from '../types';

const services = rawServices as unknown as Service[];

interface CategoryItem {
  id: ServiceCategory;
  nameKey: string;
  icon: LucideIcon;
  colorBg: string;
  colorBorder: string;
  colorText: string;
}

export const CategoryCards: React.FC = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const categories: CategoryItem[] = [
    {
      id: 'education',
      nameKey: 'categories.education',
      icon: GraduationCap,
      colorBg: 'bg-blue-50 dark:bg-blue-950/40',
      colorBorder: 'border-blue-200 dark:border-blue-900',
      colorText: 'text-blue-700 dark:text-blue-300',
    },
    {
      id: 'financial-assistance',
      nameKey: 'categories.financialAssistance',
      icon: Banknote,
      colorBg: 'bg-emerald-50 dark:bg-emerald-950/40',
      colorBorder: 'border-emerald-200 dark:border-emerald-900',
      colorText: 'text-emerald-700 dark:text-emerald-300',
    },
    {
      id: 'senior-citizens',
      nameKey: 'categories.seniorCitizens',
      icon: HeartHandshake,
      colorBg: 'bg-purple-50 dark:bg-purple-950/40',
      colorBorder: 'border-purple-200 dark:border-purple-900',
      colorText: 'text-purple-700 dark:text-purple-300',
    },
    {
      id: 'farmer-services',
      nameKey: 'categories.farmerServices',
      icon: Tractor,
      colorBg: 'bg-amber-50 dark:bg-amber-950/40',
      colorBorder: 'border-amber-200 dark:border-amber-900',
      colorText: 'text-amber-700 dark:text-amber-300',
    },
    {
      id: 'certificates',
      nameKey: 'categories.certificates',
      icon: FileCheck2,
      colorBg: 'bg-cyan-50 dark:bg-cyan-950/40',
      colorBorder: 'border-cyan-200 dark:border-cyan-900',
      colorText: 'text-cyan-700 dark:text-cyan-300',
    },
    {
      id: 'housing',
      nameKey: 'categories.housing',
      icon: HomeIcon,
      colorBg: 'bg-orange-50 dark:bg-orange-950/40',
      colorBorder: 'border-orange-200 dark:border-orange-900',
      colorText: 'text-orange-700 dark:text-orange-300',
    },
    {
      id: 'disability-services',
      nameKey: 'categories.disabilityServices',
      icon: Accessibility,
      colorBg: 'bg-rose-50 dark:bg-rose-950/40',
      colorBorder: 'border-rose-200 dark:border-rose-900',
      colorText: 'text-rose-700 dark:text-rose-300',
    },
  ];

  const getServiceCount = (catId: ServiceCategory) => {
    return services.filter((s) => s.category === catId).length;
  };

  const handleCategoryClick = (catId: ServiceCategory) => {
    navigate(`/discovery?category=${catId}`);
  };

  return (
    <section aria-labelledby="categories-heading" className="py-8 px-4 sm:px-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 border-b border-gray-200 dark:border-gray-800 pb-4">
          <div>
            <h2
              id="categories-heading"
              className="text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white"
            >
              {t('categories.title')}
            </h2>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">
              {t('categories.subtitle')}
            </p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 self-start sm:self-auto">
            7 Verified Citizen Sectors
          </span>
        </div>

        {/* Responsive Grid of Category Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const count = getServiceCount(cat.id);

            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleCategoryClick(cat.id)}
                className="group relative flex flex-col p-5 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:border-blue-500 dark:hover:border-blue-400 text-left transition-all hover:shadow-md card-accessible touch-target cursor-pointer"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-xl ${cat.colorBg} ${cat.colorText} border ${cat.colorBorder}`}>
                    <Icon className="w-6 h-6" aria-hidden="true" />
                  </div>
                  <div className="p-1.5 rounded-full bg-gray-50 dark:bg-gray-700 group-hover:bg-blue-50 dark:group-hover:bg-blue-950 text-gray-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                  </div>
                </div>

                <h3 className="text-base font-bold text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {t(cat.nameKey)}
                </h3>

                <div className="mt-3 flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                  <span className="font-medium">
                    {count > 0 ? `${count} ${t('categories.servicesCount')}` : 'Demo listing only'}
                  </span>
                  <span className="text-[11px] font-semibold text-gray-400 dark:text-gray-500">
                    Explore →
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
