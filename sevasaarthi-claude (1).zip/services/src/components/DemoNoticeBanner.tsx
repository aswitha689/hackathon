import { AlertTriangle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const DemoNoticeBanner: React.FC = () => {
  const { t } = useLanguage();

  return (
    <aside
      aria-label="Demonstration Notice"
      className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2 text-xs md:text-sm"
    >
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-200 text-amber-950 uppercase tracking-wide">
            {t('demoBadge')}
          </span>
          <span className="font-medium">
            {t('demoDisclaimer')}
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-amber-800 font-normal">
          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 text-amber-600" aria-hidden="true" />
          <span>{t('preliminaryNotice')}</span>
        </div>
      </div>
    </aside>
  );
};
