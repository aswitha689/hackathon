import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Send,
  Bot,
  Volume2,
  Minimize2,
  Mic,
  MicOff,
  Radio,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { askAssistant, getAssistantStatus } from '../utils/aiAssistant';
import type { Service } from '../types';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedFollowUps?: string[];
  source?: 'llm' | 'rule';
}

/** Renders **bold** safely as <strong> (no raw HTML injection) */
const renderRichText = (text: string): React.ReactNode =>
  text.split(/(\*\*[^*]+\*\*)/g).map((part, i) =>
    part.startsWith('**') && part.endsWith('**') && part.length > 4 ? (
      <strong key={i}>{part.slice(2, -2)}</strong>
    ) : (
      <React.Fragment key={i}>{part.replace(/\*/g, '')}</React.Fragment>
    )
  );

interface FloatingAIAssistantProps {
  currentService?: Service | null;
  contextStage?: string;
}

export const FloatingAIAssistant: React.FC<FloatingAIAssistantProps> = ({
  currentService,
  contextStage,
}) => {
  const { language } = useLanguage();
  const { speakText, settings } = useAccessibility();

  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  const [messages, setMessages] = useState<Message[]>(() => [
    {
      id: 'welcome',
      sender: 'assistant',
      text:
        language === 'te'
          ? 'నమస్కారం! నేను మీ డిజిటల్ సేవాసారథి సహాయకుడిని. అర్హత, అవసరమైన పత్రాలు లేదా దరఖాస్తు విధానం గురించి నన్ను అడగవచ్చు.'
          : language === 'hi'
          ? 'नमस्ते! मैं आपका सेवासारथी सहायक हूँ। पात्रता, आवश्यक दस्तावेज या आवेदन प्रक्रिया के बारे में मुझसे पूछें।'
          : 'Hello! I am your SevaSaarthi citizen navigator. Ask me about required documents, preliminary eligibility, or application steps.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestedFollowUps:
        language === 'te'
          ? ['ఏ పత్రాలు కావాలి?', 'నాకు అర్హత ఉందా?', 'తదుపరి ఏమి జరుగుతుంది?']
          : ['What documents do I need?', 'Am I eligible?', 'Explain in Telugu'],
    },
  ]);

  const [isThinking, setIsThinking] = useState(false);
  const [llmStatus, setLlmStatus] = useState<{ configured: boolean; model: string } | null>(null);
  const handleSendRef = useRef<(t?: string) => void>(() => {});

  useEffect(() => {
    if (isOpen) getAssistantStatus().then(setLlmStatus);
  }, [isOpen]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isThinking]);

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: Message = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsThinking(true);

    try {
      const history = messages
        .filter((m) => m.id !== 'welcome')
        .slice(-6)
        .map((m) => ({
          role: m.sender === 'user' ? ('user' as const) : ('assistant' as const),
          content: m.text,
        }));
      const response = await askAssistant(query, currentService, language, contextStage, history);
      const botMsg: Message = {
        id: `bot_${Date.now()}`,
        sender: 'assistant',
        text: response.answer,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedFollowUps: response.suggestedFollowUps,
        source: response.source,
      };
      setMessages((prev) => [...prev, botMsg]);

      // Automatically speak reply if read aloud is enabled
      if (settings.readAloudEnabled) {
        speakText(response.answer, language);
      }
    } catch {
      const errorMsg: Message = {
        id: `bot_err_${Date.now()}`,
        sender: 'assistant',
        text: 'Sorry, I encountered an issue retrieving the information. Please try again.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsThinking(false);
    }
  };

  handleSendRef.current = handleSend;

  // Voice speech-to-text inside assistant
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) return;

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;

    if (language === 'te') recognition.lang = 'te-IN';
    else if (language === 'hi') recognition.lang = 'hi-IN';
    else recognition.lang = 'en-IN';

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      if (transcript) {
        handleSendRef.current(transcript);
      }
    };

    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // ignore
        }
      }
    };
  }, [language]);

  const toggleMic = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      try {
        if (recognitionRef.current) {
          if (language === 'te') recognitionRef.current.lang = 'te-IN';
          else if (language === 'hi') recognitionRef.current.lang = 'hi-IN';
          else recognitionRef.current.lang = 'en-IN';

          recognitionRef.current.start();
          setIsListening(true);
        }
      } catch (e) {
        console.warn('Speech recognition start failed', e);
        setIsListening(false);
      }
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-40">
      {/* Floating Toggle Button */}
      {!isOpen && (
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          aria-label="Open AI Assistant"
          aria-expanded={isOpen}
          className="group touch-target flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold text-sm shadow-xl hover:shadow-2xl transition-all scale-100 hover:scale-105"
        >
          <div className="relative">
            <Bot className="w-5 h-5" aria-hidden="true" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-white animate-pulse" />
          </div>
          <span>SevaSaarthi AI</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/20 uppercase tracking-wider">
            Demo
          </span>
        </button>
      )}

      {/* Floating Chat Modal */}
      {isOpen && (
        <div
          role="dialog"
          aria-label="AI Citizen Navigator Assistant"
          className="w-[92vw] sm:w-[380px] md:w-[420px] h-[560px] max-h-[85vh] bg-white dark:bg-gray-900 rounded-3xl shadow-2xl border border-gray-200 dark:border-gray-700 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200 card-accessible"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-blue-700 to-indigo-700 text-white">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-white/10 backdrop-blur-md">
                <Bot className="w-5 h-5 text-white" aria-hidden="true" />
              </div>
              <div>
                <h3 className="text-sm font-bold flex items-center gap-1.5">
                  <span>SevaSaarthi Assistant</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/20 uppercase font-semibold">
                    {llmStatus?.configured ? 'Claude' : 'Demo'}
                  </span>
                </h3>
                <p className="text-[11px] text-blue-100/90 truncate max-w-[200px]">
                  {currentService ? currentService.name.en : 'Citizen Services Navigator'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                aria-label="Minimize Assistant"
                className="p-1.5 rounded-lg hover:bg-white/20 text-white transition-colors"
              >
                <Minimize2 className="w-4 h-4" aria-hidden="true" />
              </button>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                aria-label="Close Assistant"
                className="p-1.5 rounded-lg hover:bg-white/20 text-white transition-colors"
              >
                <X className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50 dark:bg-gray-950/60">
            {messages.map((msg) => {
              const isBot = msg.sender === 'assistant';
              return (
                <div key={msg.id} className="space-y-2">
                  <div
                    className={`flex items-start gap-2.5 ${
                      isBot ? 'justify-start' : 'justify-end'
                    }`}
                  >
                    {isBot && (
                      <div className="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 flex items-center justify-center shrink-0 mt-0.5">
                        <Bot className="w-4 h-4" aria-hidden="true" />
                      </div>
                    )}
                    <div
                      className={`max-w-[84%] rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm leading-relaxed whitespace-pre-line ${
                        isBot
                          ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 border border-gray-200 dark:border-gray-700 shadow-2xs'
                          : 'bg-blue-600 text-white font-medium rounded-tr-none'
                      }`}
                    >
                      {isBot ? renderRichText(msg.text) : msg.text}

                      {/* Read aloud helper for bot message */}
                      {isBot && (
                        <div className="mt-2 pt-1.5 border-t border-gray-100 dark:border-gray-700/60 flex items-center justify-between text-[11px] text-gray-500">
                          <button
                            type="button"
                            onClick={() => speakText(msg.text, language)}
                            aria-label="Read this message out loud"
                            className="inline-flex items-center gap-1 text-blue-600 dark:text-blue-400 hover:underline font-medium"
                          >
                            <Volume2 className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>Read Aloud</span>
                          </button>
                          <span className="text-[10px] text-gray-500">
                            {msg.source === 'llm' ? 'Claude AI' : msg.source === 'rule' ? 'Offline help' : ''} {msg.timestamp}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Suggestion Chips */}
                  {isBot && msg.suggestedFollowUps && msg.suggestedFollowUps.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pl-9">
                      {msg.suggestedFollowUps.map((chip, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleSend(chip)}
                          className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-white dark:bg-gray-800 border border-blue-200 dark:border-blue-900 text-blue-700 dark:text-blue-300 hover:bg-blue-50 dark:hover:bg-blue-950 transition-colors shadow-2xs"
                        >
                          {chip}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
            {isThinking && (
              <div className="flex items-center gap-2 pl-2 text-xs text-blue-600 dark:text-blue-400 animate-pulse">
                <Bot className="w-4 h-4 animate-spin" />
                <span>SevaSaarthi is finding guidance...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Voice Listening Active Bar */}
          {isListening && (
            <div className="px-4 py-2 bg-red-50 dark:bg-red-950/70 border-t border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs flex items-center justify-between animate-pulse">
              <div className="flex items-center gap-2">
                <Radio className="w-3.5 h-3.5 text-red-600" aria-hidden="true" />
                <span>Listening... speak your question now</span>
              </div>
              <button
                type="button"
                onClick={toggleMic}
                className="text-[11px] font-bold underline"
              >
                Stop
              </button>
            </div>
          )}

          {/* Input footer */}
          <div className="p-3 border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 space-y-2">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-1.5 bg-gray-100 dark:bg-gray-800 rounded-2xl px-2.5 py-1.5 border border-gray-200 dark:border-gray-700 focus-within:border-blue-500"
            >
              {/* Mic inside assistant */}
              <button
                type="button"
                onClick={toggleMic}
                aria-label={isListening ? 'Stop listening' : 'Speak question'}
                className={`p-1.5 rounded-xl transition-colors ${
                  isListening
                    ? 'bg-red-600 text-white animate-pulse'
                    : 'text-gray-500 hover:text-blue-600 dark:text-gray-400'
                }`}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>

              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask e.g. 'what documents do I need?'"
                aria-label="Ask assistant a question"
                className="w-full bg-transparent text-xs sm:text-sm text-gray-900 dark:text-white focus:outline-hidden py-1 placeholder-gray-400"
              />

              <button
                type="submit"
                disabled={!input.trim()}
                aria-label="Send question"
                className="p-1.5 rounded-xl bg-blue-600 disabled:opacity-40 text-white hover:bg-blue-700 transition-colors shrink-0"
              >
                <Send className="w-4 h-4" aria-hidden="true" />
              </button>
            </form>
            <p className="text-[10px] text-gray-400 text-center">
              Preliminary guidance assistant • Demonstration data only
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
