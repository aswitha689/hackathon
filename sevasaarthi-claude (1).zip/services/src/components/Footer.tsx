import React from 'react';
import { Link } from 'react-router-dom';
import { Landmark, ShieldAlert, BarChart3, ShieldCheck } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="mt-auto border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-400 py-8 px-4 sm:px-6 transition-colors">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
              <Landmark className="w-4 h-4" aria-hidden="true" />
            </div>
            <div>
              <p className="text-sm font-bold text-gray-900 dark:text-white">
                {t('appName')}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {t('tagline')}
              </p>
            </div>
          </div>

          {/* Quick links to Admin & Analytics */}
          <div className="flex items-center gap-3 text-xs font-semibold">
            <Link
              to="/admin"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200 transition-colors"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" aria-hidden="true" />
              <span>Officer Portal (/admin)</span>
            </Link>
            <Link
              to="/analytics"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200 transition-colors"
            >
              <BarChart3 className="w-3.5 h-3.5 text-purple-600" aria-hidden="true" />
              <span>Live Analytics (/analytics)</span>
            </Link>
          </div>

          <div className="flex items-center gap-2 text-xs bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-amber-800 dark:text-amber-300 px-3.5 py-1.5 rounded-full">
            <ShieldAlert className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            <span>Hackathon Demonstration Prototype • Simulated Demo Data Only</span>
          </div>
        </div>

        <div className="border-t border-gray-100 dark:border-gray-800 pt-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-gray-500 dark:text-gray-400 text-center sm:text-left">
          <p>
            Designed with accessibility, multilingual support, and voice-first simplicity for Indian citizens.
          </p>
          <p className="flex items-center gap-1 justify-center font-medium">
            <span>Built for 24h Hackathon</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
