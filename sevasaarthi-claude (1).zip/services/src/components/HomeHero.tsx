import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mic, MicOff, Search, Volume2, ArrowRight, Radio } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAccessibility } from '../context/AccessibilityContext';

export const HomeHero: React.FC = () => {
  const { language, t } = useLanguage();
  const { speakText, stopSpeaking, isSpeaking, settings } = useAccessibility();
  const navigate = useNavigate();

  const [query, setQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  // Language display name
  const langName = language === 'te' ? 'Telugu (తెలుగు)' : language === 'hi' ? 'Hindi (हिंदी)' : 'English';

  // Initialize Web Speech API for Speech-to-Text
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;

    // Set recognition language matching UI language
    if (language === 'te') {
      recognition.lang = 'te-IN';
    } else if (language === 'hi') {
      recognition.lang = 'hi-IN';
    } else {
      recognition.lang = 'en-IN';
    }

    recognition.onresult = (event: any) => {
      let transcript = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      if (transcript) {
        setQuery(transcript);
      }
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      setIsListening(false);
      if (event.error === 'not-allowed') {
        setMicError('Microphone permission denied. Please allow microphone access in your browser.');
      } else if (event.error !== 'no-speech') {
        setMicError(`Voice input: ${event.error}`);
      }
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // ignore
        }
      }
    };
  }, [language]);

  const toggleListening = () => {
    setMicError(null);
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setMicError(t('hero.micNotSupported'));
      return;
    }

    if (isListening) {
      try {
        recognitionRef.current?.stop();
      } catch {
        // ignore
      }
      setIsListening(false);
    } else {
      try {
        if (recognitionRef.current) {
          if (language === 'te') recognitionRef.current.lang = 'te-IN';
          else if (language === 'hi') recognitionRef.current.lang = 'hi-IN';
          else recognitionRef.current.lang = 'en-IN';

          recognitionRef.current.start();
          setIsListening(true);
        }
      } catch (e: any) {
        console.warn('Failed to start speech recognition', e);
        setIsListening(false);
      }
    }
  };

  const handleSearch = (searchQuery?: string) => {
    const q = searchQuery !== undefined ? searchQuery : query;
    if (!q || !q.trim()) return;
    navigate(`/discovery?q=${encodeURIComponent(q.trim())}`);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSearch();
    }
  };

  // Persona sample prompts
  const samplePrompts = [
    {
      text: t('hero.samplePrompt1'),
      tag: '🎓 College Scholarship (Anitha Demo)',
    },
    {
      text: t('hero.samplePrompt2'),
      tag: '👴 Senior Pension',
    },
    {
      text: t('hero.samplePrompt3'),
      tag: '🌾 Farmer Grant',
    },
    {
      text: t('hero.samplePrompt4'),
      tag: '📄 Income Certificate',
    },
  ];

  const handleReadHero = () => {
    if (isSpeaking) {
      stopSpeaking();
    } else {
      const speech = `${t('hero.title')}. ${t('hero.voicePrompt')}. ${t('hero.subtitle')}`;
      speakText(speech, language);
    }
  };

  return (
    <section aria-labelledby="hero-title" className="relative pt-6 pb-12 px-4 sm:px-6">
      <div className="max-w-4xl mx-auto text-center space-y-6">
        {/* Read Aloud button for hero explanation */}
        {settings.readAloudEnabled && (
          <div className="flex justify-center">
            <button
              type="button"
              onClick={handleReadHero}
              aria-label={isSpeaking ? t('common.stopSpeech') : t('common.readAloud')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                isSpeaking
                  ? 'bg-amber-100 text-amber-800 border-amber-300 ring-2 ring-amber-400/40'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:border-blue-500'
              }`}
            >
              <Volume2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" aria-hidden="true" />
              <span>{isSpeaking ? t('common.speaking') : t('common.readAloud')}</span>
            </button>
          </div>
        )}

        {/* Main Title & Subtitle */}
        <div className="space-y-3">
          <h1
            id="hero-title"
            className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-gray-900 dark:text-white"
          >
            {t('hero.title')}
          </h1>

          <div className="inline-block px-4 py-1.5 rounded-2xl bg-blue-50 dark:bg-blue-950/70 border border-blue-200 dark:border-blue-800/80">
            <p className="text-base sm:text-lg font-bold text-blue-800 dark:text-blue-300 flex items-center justify-center gap-2">
              <span>{t('hero.voicePrompt')}</span>
            </p>
          </div>

          <p className="text-sm sm:text-base text-gray-600 dark:text-gray-300 max-w-xl mx-auto">
            {t('hero.subtitle')}
          </p>
        </div>

        {/* Search & Voice Box */}
        <div className="max-w-3xl mx-auto">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSearch();
            }}
            className={`relative flex flex-col sm:flex-row items-stretch sm:items-center bg-white dark:bg-gray-800 rounded-3xl sm:rounded-full border-2 p-2 sm:p-2.5 gap-2 transition-all card-accessible ${
              isListening
                ? 'border-red-500 ring-4 ring-red-500/20 shadow-lg'
                : 'border-gray-300 dark:border-gray-700 focus-within:border-blue-600 dark:focus-within:border-blue-500 shadow-lg shadow-gray-200/50 dark:shadow-none'
            }`}
          >
            {/* Input field */}
            <div className="flex-1 flex items-center pl-3">
              <Search className="w-5 h-5 text-gray-400 dark:text-gray-500 mr-2 shrink-0" aria-hidden="true" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={t('hero.searchPlaceholder')}
                aria-label={t('hero.searchPlaceholder')}
                className="w-full bg-transparent text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 text-sm sm:text-base focus:outline-hidden py-2"
              />
            </div>

            {/* Actions: Voice Button + Search Submit Button */}
            <div className="flex items-center gap-2 justify-end">
              {/* Mic Speech Button */}
              <button
                type="button"
                onClick={toggleListening}
                aria-label={isListening ? t('hero.stopListening') : t('hero.voicePrompt')}
                aria-pressed={isListening}
                title={isListening ? t('hero.stopListening') : `Speak in ${langName}`}
                className={`touch-target p-3 rounded-full flex items-center justify-center transition-all ${
                  isListening
                    ? 'bg-red-600 text-white animate-pulse ring-4 ring-red-400/40'
                    : 'bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200'
                }`}
              >
                {isListening ? (
                  <MicOff className="w-5 h-5" aria-hidden="true" />
                ) : (
                  <Mic className="w-5 h-5 text-blue-600 dark:text-blue-400" aria-hidden="true" />
                )}
              </button>

              {/* Submit Search Button */}
              <button
                type="submit"
                className="touch-target px-5 py-3 rounded-xl sm:rounded-full bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm sm:text-base transition-colors flex items-center justify-center gap-2 shadow-sm"
              >
                <span>{t('hero.searchButton')}</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          </form>

          {/* Voice Listening Feedback & Audio Wave Effect */}
          {isListening && (
            <div
              role="status"
              className="mt-3 py-3 px-5 rounded-2xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs sm:text-sm font-semibold flex items-center justify-between gap-3 animate-in fade-in"
            >
              <div className="flex items-center gap-2.5">
                <Radio className="w-4 h-4 text-red-600 animate-pulse" aria-hidden="true" />
                <span>Listening in <strong>{langName}</strong>... speak now</span>
              </div>

              {/* Simulated Audio Bars */}
              <div className="flex items-center gap-1">
                <span className="w-1 h-3 bg-red-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1 h-5 bg-red-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1 h-4 bg-red-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                <span className="w-1 h-6 bg-red-700 rounded-full animate-bounce" style={{ animationDelay: '75ms' }} />
                <span className="w-1 h-3 bg-red-500 rounded-full animate-bounce" style={{ animationDelay: '225ms' }} />
              </div>
            </div>
          )}

          {/* Voice Fallback / Error Notice */}
          {micError && (
            <div
              role="alert"
              className="mt-3 p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-300 text-xs sm:text-sm"
            >
              {micError}
            </div>
          )}
        </div>

        {/* Sample Persona Prompts for fast testing */}
        <div className="pt-2">
          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2.5">
            {t('hero.samplePromptsLabel')}
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {samplePrompts.map((item, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setQuery(item.text);
                  handleSearch(item.text);
                }}
                className="text-xs font-medium px-3.5 py-2 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:border-blue-500 dark:hover:border-blue-400 hover:bg-blue-50/50 dark:hover:bg-blue-950/40 text-gray-700 dark:text-gray-200 transition-colors shadow-2xs text-left"
              >
                <span>{item.tag}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
