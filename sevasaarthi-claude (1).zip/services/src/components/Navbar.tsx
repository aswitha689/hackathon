import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Eye, Database, Search, Landmark, Bell } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { AccessibilityModal } from './AccessibilityModal';
import { NotificationModal } from './NotificationModal';
import {
  getCitizenNotifications,
  NOTIFICATION_EVENT,
  type CitizenNotification,
} from '../utils/storage';
import type { Language } from '../types';

export const Navbar: React.FC = () => {
  const { language, setLanguage, t } = useLanguage();
  const { settings, toggleDataSaver } = useAccessibility();
  const [isA11yOpen, setIsA11yOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState<CitizenNotification[]>(getCitizenNotifications);

  const refreshNotifications = () => {
    setNotifications(getCitizenNotifications());
  };

  useEffect(() => {
    const handleUpdate = () => {
      refreshNotifications();
    };

    window.addEventListener(NOTIFICATION_EVENT, handleUpdate);
    window.addEventListener('storage', handleUpdate);

    return () => {
      window.removeEventListener(NOTIFICATION_EVENT, handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  // Keyboard shortcut listener: Alt+A -> A11y, Alt+N -> Notifications
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'a' || e.key === 'A')) {
        e.preventDefault();
        setIsA11yOpen((prev) => !prev);
      } else if (e.altKey && (e.key === 'n' || e.key === 'N')) {
        e.preventDefault();
        setIsNotifOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const languages: { code: Language; label: string; nativeName: string }[] = [
    { code: 'en', label: 'English', nativeName: 'EN' },
    { code: 'te', label: 'Telugu', nativeName: 'తెలుగు' },
    { code: 'hi', label: 'Hindi', nativeName: 'हिंदी' },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md border-b border-gray-200 dark:border-gray-800 transition-colors">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-3">
          {/* Logo & Tagline */}
          <Link
            to="/"
            className="flex items-center gap-3 group focus-visible:outline-2 focus-visible:outline-blue-600 rounded-lg shrink-0"
            aria-label="SevaSaarthi Home"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <Landmark className="w-5 h-5" aria-hidden="true" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-tight text-gray-950 dark:text-white">
                  {t('appName')}
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 dark:bg-blue-900/60 dark:text-blue-300">
                  Demo
                </span>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 font-medium hidden sm:block">
                {t('tagline')}
              </p>
            </div>
          </Link>

          {/* Right Action Bar */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Language Switcher Buttons EN | తెలుగు | हिंदी */}
            <div
              role="group"
              aria-label="Language selection"
              className="flex items-center p-1 bg-gray-100 dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700"
            >
              {languages.map((lang) => {
                const isActive = language === lang.code;
                return (
                  <button
                    key={lang.code}
                    type="button"
                    onClick={() => setLanguage(lang.code)}
                    aria-pressed={isActive}
                    title={`Switch language to ${lang.label}`}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all touch-target flex items-center justify-center ${
                      isActive
                        ? 'bg-white dark:bg-gray-700 text-blue-700 dark:text-blue-300 shadow-xs'
                        : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                    }`}
                  >
                    {lang.nativeName}
                  </button>
                );
              })}
            </div>

            {/* Notification Bell with Badge */}
            <button
              type="button"
              onClick={() => setIsNotifOpen(true)}
              aria-label={`Citizen notifications, ${unreadCount} unread`}
              title="Notifications (Alt+N)"
              className="relative p-2 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-blue-500 text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-gray-700/50 transition-colors touch-target"
            >
              <Bell className="w-4 h-4 text-blue-600 dark:text-blue-400" aria-hidden="true" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full bg-red-600 text-white font-bold text-[10px] ring-2 ring-white dark:ring-gray-900 animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Accessibility Panel Trigger */}
            <button
              type="button"
              onClick={() => setIsA11yOpen(true)}
              aria-label={`${t('nav.accessibility')} (Shortcut: Alt+A)`}
              title={`${t('nav.accessibility')} (Alt+A)`}
              className="p-2 sm:px-3 sm:py-2 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-blue-500 text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-gray-700/50 transition-colors flex items-center gap-1.5 text-xs font-semibold"
            >
              <Eye className="w-4 h-4 text-blue-600 dark:text-blue-400" aria-hidden="true" />
              <span className="hidden md:inline">{t('nav.accessibility')}</span>
            </button>

            {/* Quick Data Saver Toggle */}
            <button
              type="button"
              onClick={toggleDataSaver}
              aria-pressed={settings.dataSaver}
              title={settings.dataSaver ? t('nav.dataSaverOn') : t('nav.dataSaverOff')}
              className={`p-2 rounded-xl border text-xs font-medium transition-colors flex items-center gap-1.5 ${
                settings.dataSaver
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                  : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <Database className="w-4 h-4" aria-hidden="true" />
              <span className="hidden lg:inline">
                {settings.dataSaver ? 'Data Saver: ON' : 'Data Saver'}
              </span>
            </button>

            {/* Track Application Quick Link */}
            <Link
              to="/track"
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 text-xs font-semibold transition-colors"
            >
              <Search className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t('nav.track')}</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Accessibility Dialog */}
      <AccessibilityModal isOpen={isA11yOpen} onClose={() => setIsA11yOpen(false)} />

      {/* Citizen Notification Dialog */}
      <NotificationModal
        isOpen={isNotifOpen}
        onClose={() => setIsNotifOpen(false)}
        notifications={notifications}
        onRefresh={refreshNotifications}
      />
    </>
  );
};
