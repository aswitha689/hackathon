import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, X, CheckCheck, Trash2, ArrowRight, Sparkles } from 'lucide-react';
import {
  markNotificationsAsRead,
  clearNotifications,
  addCitizenNotification,
  type CitizenNotification,
} from '../utils/storage';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: CitizenNotification[];
  onRefresh: () => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  notifications,
  onRefresh,
}) => {
  const navigate = useNavigate();

  if (!isOpen) return null;

  const handleNotificationClick = (notif: CitizenNotification) => {
    markNotificationsAsRead();
    onRefresh();
    onClose();
    if (notif.applicationId) {
      navigate(`/track?id=${encodeURIComponent(notif.applicationId)}`);
    }
  };

  const handleSimulateNewNotification = () => {
    addCitizenNotification({
      applicationId: 'SV-2026-001247',
      title: 'Field Verification Completed (Demo)',
      message: 'District Social Welfare Officer approved tuition fee sanction order for Anitha (SV-2026-001247).',
    });
    onRefresh();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="notif-modal-title"
      className="fixed inset-0 z-50 flex items-start justify-end p-4 sm:p-6 bg-black/40 backdrop-blur-2xs"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-sm sm:max-w-md bg-white dark:bg-gray-900 rounded-3xl shadow-2xl border border-gray-200 dark:border-gray-700 overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in slide-in-from-top-4 duration-200 card-accessible">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-gray-800 bg-gray-50/70 dark:bg-gray-800/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300">
              <Bell className="w-4 h-4" aria-hidden="true" />
            </div>
            <div>
              <h2 id="notif-modal-title" className="text-sm font-bold text-gray-900 dark:text-white">
                Citizen Notifications
              </h2>
              <span className="text-[11px] text-gray-500 dark:text-gray-400">
                {notifications.filter((n) => !n.read).length} unread updates
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close notifications"
            className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            <X className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>

        {/* Quick Demo Simulator Banner */}
        <div className="px-5 py-2.5 bg-amber-50 dark:bg-amber-950/40 border-b border-amber-200 dark:border-amber-900 flex items-center justify-between text-xs">
          <span className="text-[11px] font-medium text-amber-900 dark:text-amber-200">
            Testing live updates?
          </span>
          <button
            type="button"
            onClick={handleSimulateNewNotification}
            className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 dark:text-amber-300 hover:underline"
          >
            <Sparkles className="w-3 h-3 text-amber-600" aria-hidden="true" />
            <span>Simulate Officer Ping</span>
          </button>
        </div>

        {/* List of Notifications */}
        <div className="flex-1 overflow-y-auto divide-y divide-gray-100 dark:divide-gray-800 p-2 space-y-1">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-xs text-gray-400">
              <Bell className="w-8 h-8 mx-auto text-gray-300 dark:text-gray-600 mb-2" aria-hidden="true" />
              <span>No notifications right now</span>
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                onClick={() => handleNotificationClick(notif)}
                className={`p-3.5 rounded-2xl cursor-pointer transition-colors flex items-start gap-3 ${
                  notif.read
                    ? 'hover:bg-gray-50 dark:hover:bg-gray-800/60'
                    : 'bg-blue-50/50 dark:bg-blue-950/30 hover:bg-blue-50 dark:hover:bg-blue-950/50'
                }`}
              >
                <div className="mt-0.5">
                  {!notif.read ? (
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-600 block ring-2 ring-blue-200 dark:ring-blue-900" />
                  ) : (
                    <span className="w-2.5 h-2.5 rounded-full bg-gray-300 dark:bg-gray-600 block" />
                  )}
                </div>

                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between gap-1">
                    <h3 className="text-xs font-bold text-gray-900 dark:text-white">
                      {notif.title}
                    </h3>
                    <span className="text-[10px] text-gray-400 shrink-0">
                      {notif.timestamp}
                    </span>
                  </div>

                  <p className="text-xs text-gray-600 dark:text-gray-300 leading-snug">
                    {notif.message}
                  </p>

                  {notif.applicationId && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-600 dark:text-blue-400 pt-0.5">
                      <span>View application {notif.applicationId}</span>
                      <ArrowRight className="w-3 h-3" aria-hidden="true" />
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer actions */}
        <div className="p-3 border-t border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/50 flex items-center justify-between text-xs">
          <button
            type="button"
            onClick={() => {
              markNotificationsAsRead();
              onRefresh();
            }}
            className="flex items-center gap-1 text-gray-600 dark:text-gray-400 hover:text-blue-600 font-medium"
          >
            <CheckCheck className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Mark all read</span>
          </button>

          <button
            type="button"
            onClick={() => {
              clearNotifications();
              onRefresh();
            }}
            className="flex items-center gap-1 text-gray-500 hover:text-red-600 font-medium"
          >
            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Clear all</span>
          </button>
        </div>
      </div>
    </div>
  );
};
