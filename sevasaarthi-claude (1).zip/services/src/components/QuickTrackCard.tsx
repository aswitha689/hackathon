import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Clock, ArrowRight } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const QuickTrackCard: React.FC = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [appId, setAppId] = useState('');

  const handleTrack = (idToTrack?: string) => {
    const target = idToTrack || appId;
    if (!target || !target.trim()) return;
    navigate(`/track?id=${encodeURIComponent(target.trim())}`);
  };

  return (
    <section aria-labelledby="track-heading" className="py-6 px-4 sm:px-6">
      <div className="max-w-4xl mx-auto rounded-3xl bg-gradient-to-r from-blue-900 to-indigo-900 text-white p-6 sm:p-8 shadow-xl relative overflow-hidden card-accessible">
        {/* Decorative background glow */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 rounded-full bg-blue-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-md">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-800/80 border border-blue-700 text-blue-200 text-xs font-semibold">
              <Clock className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Real-Time Status</span>
            </div>
            <h2 id="track-heading" className="text-xl sm:text-2xl font-bold tracking-tight">
              {t('quickTrack.title')}
            </h2>
            <p className="text-xs sm:text-sm text-blue-100/80">
              {t('quickTrack.subtitle')}
            </p>
          </div>

          <div className="w-full md:w-auto flex-1 max-w-md space-y-2">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleTrack();
              }}
              className="flex items-center bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-1.5 focus-within:border-white focus-within:bg-white/15 transition-all"
            >
              <div className="pl-3 pr-2 text-blue-200">
                <Search className="w-4 h-4" aria-hidden="true" />
              </div>
              <input
                type="text"
                value={appId}
                onChange={(e) => setAppId(e.target.value)}
                placeholder={t('quickTrack.placeholder')}
                aria-label={t('quickTrack.placeholder')}
                className="w-full bg-transparent text-white placeholder-blue-200/60 text-sm focus:outline-hidden py-2"
              />
              <button
                type="submit"
                className="touch-target px-4 py-2 rounded-xl bg-white text-blue-900 font-bold text-xs sm:text-sm hover:bg-blue-50 transition-colors flex items-center gap-1 shrink-0 shadow-sm"
              >
                <span>{t('quickTrack.trackButton')}</span>
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            </form>

            {/* Quick Demo ID button */}
            <div className="flex items-center justify-between text-[11px] text-blue-200/80 px-1">
              <span>Looking for demo reference?</span>
              <button
                type="button"
                onClick={() => {
                  setAppId('SV-2026-001247');
                  handleTrack('SV-2026-001247');
                }}
                className="underline hover:text-white font-medium"
              >
                {t('quickTrack.anithaDemo')}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
