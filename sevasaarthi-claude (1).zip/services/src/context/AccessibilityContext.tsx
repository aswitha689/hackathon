import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { AccessibilitySettings, TextSize, ContrastMode } from '../types';

interface AccessibilityContextType {
  settings: AccessibilitySettings;
  setTextSize: (size: TextSize) => void;
  setContrastMode: (mode: ContrastMode) => void;
  toggleReduceMotion: () => void;
  toggleSimplifiedInterface: () => void;
  toggleReadAloud: () => void;
  toggleDataSaver: () => void;
  resetSettings: () => void;
  speakText: (text: string, lang?: string) => void;
  stopSpeaking: () => void;
  isSpeaking: boolean;
}

const defaultSettings: AccessibilitySettings = {
  textSize: 'normal',
  contrastMode: 'default',
  reduceMotion: false,
  simplifiedInterface: false,
  readAloudEnabled: true,
  dataSaver: false,
};

const STORAGE_KEY = 'sevasaarthi_a11y_settings';

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export const AccessibilityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AccessibilitySettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return { ...defaultSettings, ...JSON.parse(saved) };
      }
    } catch (e) {
      console.error('Failed to parse a11y settings from localStorage', e);
    }
    return defaultSettings;
  });

  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // Sync with localStorage & root DOM classes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save a11y settings', e);
    }

    const root = document.documentElement;

    // Text size class
    root.classList.remove('text-size-normal', 'text-size-large', 'text-size-xlarge');
    root.classList.add(`text-size-${settings.textSize}`);

    // Contrast class
    root.classList.remove('contrast-default', 'contrast-high', 'contrast-dark');
    root.classList.add(`contrast-${settings.contrastMode}`);

    // Reduce motion
    if (settings.reduceMotion || settings.dataSaver) {
      root.classList.add('reduce-motion');
    } else {
      root.classList.remove('reduce-motion');
    }

    // Simplified interface
    if (settings.simplifiedInterface) {
      root.classList.add('simplified-mode');
    } else {
      root.classList.remove('simplified-mode');
    }

    // Data saver
    if (settings.dataSaver) {
      root.classList.add('data-saver');
    } else {
      root.classList.remove('data-saver');
    }
  }, [settings]);

  // Voice speech synthesis
  const stopSpeaking = useCallback(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, []);

  const speakText = useCallback((text: string, lang: string = 'en') => {
    if (!('speechSynthesis' in window)) {
      console.warn('Speech synthesis not supported in this browser.');
      return;
    }

    window.speechSynthesis.cancel();

    if (!text || text.trim() === '') return;

    // Strip markdown formatting symbols for natural speech
    const cleanText = text
      .replace(/[*_#`~[\]()]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanText);

    // Language mapping
    if (lang === 'te') {
      utterance.lang = 'te-IN';
    } else if (lang === 'hi') {
      utterance.lang = 'hi-IN';
    } else {
      utterance.lang = 'en-IN';
    }

    // Attempt to pick matching installed voice if available
    const voices = window.speechSynthesis.getVoices();
    if (voices && voices.length > 0) {
      const matchedVoice = voices.find(
        (v) =>
          v.lang.toLowerCase() === utterance.lang.toLowerCase() ||
          (lang === 'te' && v.lang.toLowerCase().startsWith('te')) ||
          (lang === 'hi' && v.lang.toLowerCase().startsWith('hi')) ||
          (lang === 'en' && v.lang.toLowerCase().includes('en-in'))
      );
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }
    }

    utterance.rate = 0.95; // Gentle pace
    utterance.pitch = 1.0;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const setTextSize = (textSize: TextSize) => {
    setSettings((prev) => ({ ...prev, textSize }));
  };

  const setContrastMode = (contrastMode: ContrastMode) => {
    setSettings((prev) => ({ ...prev, contrastMode }));
  };

  const toggleReduceMotion = () => {
    setSettings((prev) => ({ ...prev, reduceMotion: !prev.reduceMotion }));
  };

  const toggleSimplifiedInterface = () => {
    setSettings((prev) => ({ ...prev, simplifiedInterface: !prev.simplifiedInterface }));
  };

  const toggleReadAloud = () => {
    setSettings((prev) => ({ ...prev, readAloudEnabled: !prev.readAloudEnabled }));
  };

  const toggleDataSaver = () => {
    setSettings((prev) => ({ ...prev, dataSaver: !prev.dataSaver }));
  };

  const resetSettings = () => {
    setSettings(defaultSettings);
    stopSpeaking();
  };

  return (
    <AccessibilityContext.Provider
      value={{
        settings,
        setTextSize,
        setContrastMode,
        toggleReduceMotion,
        toggleSimplifiedInterface,
        toggleReadAloud,
        toggleDataSaver,
        resetSettings,
        speakText,
        stopSpeaking,
        isSpeaking,
      }}
    >
      {children}
    </AccessibilityContext.Provider>
  );
};

export const useAccessibility = (): AccessibilityContextType => {
  const context = useContext(AccessibilityContext);
  if (!context) {
    throw new Error('useAccessibility must be used within an AccessibilityProvider');
  }
  return context;
};
