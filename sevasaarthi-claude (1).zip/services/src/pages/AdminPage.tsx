import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Users,
  FileText,
  Clock,
  CheckCircle2,
  Bot,
  Eye,
  Search,
  Filter,
  ArrowRight,
  ShieldCheck,
  Send,
  X,
  FileCheck2,
} from 'lucide-react';
import {
  getStoredApplications,
  updateApplicationStatus,
  addCitizenNotification,
} from '../utils/storage';
import type { ApplicationRecord } from '../types';

export const AdminPage: React.FC = () => {
  const [applications, setApplications] = useState<ApplicationRecord[]>(getStoredApplications);
  const [searchFilter, setSearchFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedApp, setSelectedApp] = useState<ApplicationRecord | null>(null);
  const [newStatus, setNewStatus] = useState<ApplicationRecord['status']>('Documents Received');
  const [statusNote, setStatusNote] = useState('');
  const [updateFeedback, setUpdateFeedback] = useState<string | null>(null);

  const refreshList = () => {
    const fresh = getStoredApplications();
    setApplications(fresh);
    if (selectedApp) {
      const refreshedSelected = fresh.find((a) => a.id === selectedApp.id);
      if (refreshedSelected) setSelectedApp(refreshedSelected);
    }
  };

  useEffect(() => {
    refreshList();
  }, []);

  // Filtered applications
  const filteredApps = applications.filter((app) => {
    const matchesSearch =
      app.citizenName.toLowerCase().includes(searchFilter.toLowerCase()) ||
      app.id.toLowerCase().includes(searchFilter.toLowerCase()) ||
      app.serviceName.toLowerCase().includes(searchFilter.toLowerCase());

    const matchesStatus = statusFilter === 'All' || app.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Calculate metrics
  const totalAppsCount = applications.length;
  const pendingCount = applications.filter((a) => a.status !== 'Completed').length;
  const completedCount = applications.filter((a) => a.status === 'Completed').length;

  const handleOpenDetail = (app: ApplicationRecord) => {
    setSelectedApp(app);
    setNewStatus(app.status);
    setStatusNote('');
    setUpdateFeedback(null);
  };

  const handleStatusUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApp) return;

    const note = statusNote.trim() || `Status updated to ${newStatus} by Welfare Officer.`;
    const success = await updateApplicationStatus(selectedApp.id, newStatus, note);

    if (success) {
      setUpdateFeedback(`Status updated to "${newStatus}" and citizen notification sent! 🎉`);
      refreshList();
      setTimeout(() => {
        setUpdateFeedback(null);
      }, 3500);
    }
  };

  const handleSendCustomNotification = (app: ApplicationRecord) => {
    addCitizenNotification({
      applicationId: app.id,
      title: 'Action Required / Update (Demo)',
      message: `District Welfare Officer sent an inquiry regarding your ${app.serviceName} application.`,
    });
    setUpdateFeedback(`Custom alert dispatched to ${app.citizenName} (${app.id})!`);
    setTimeout(() => setUpdateFeedback(null), 3500);
  };

  return (
    <main id="main-content" className="flex-1 py-8 px-4 sm:px-6 max-w-7xl mx-auto w-full space-y-8">
      {/* Top Banner & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 dark:border-gray-800 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300">
              Department Portal
            </span>
            <span className="text-xs text-amber-700 dark:text-amber-300 font-semibold bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 px-2 py-0.5 rounded">
              Simulated Demo Data
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white">
            Welfare Officer Admin Portal
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
            Manage citizen service submissions, verify proofs, and trigger real-time citizen status notifications.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Link
            to="/analytics"
            className="px-4 py-2 rounded-xl bg-purple-50 dark:bg-purple-950/60 border border-purple-200 dark:border-purple-800 text-purple-700 dark:text-purple-300 text-xs font-bold hover:bg-purple-100 transition-colors"
          >
            View Analytics →
          </Link>
          <Link
            to="/"
            className="px-4 py-2 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-200 text-xs font-semibold hover:bg-gray-200 transition-colors"
          >
            Citizen App Home
          </Link>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Total Citizens */}
        <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-2xs card-accessible">
          <div className="flex items-center justify-between text-gray-400 mb-2">
            <span className="text-xs font-medium">Total Citizens</span>
            <Users className="w-4 h-4 text-blue-600" aria-hidden="true" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">1,420</div>
          <span className="text-[10px] text-gray-400 block mt-1">Simulated demo data</span>
        </div>

        {/* Total Applications */}
        <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-2xs card-accessible">
          <div className="flex items-center justify-between text-gray-400 mb-2">
            <span className="text-xs font-medium">Applications</span>
            <FileText className="w-4 h-4 text-indigo-600" aria-hidden="true" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-gray-900 dark:text-white">{totalAppsCount}</div>
          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold block mt-1">Live in localStorage</span>
        </div>

        {/* Pending */}
        <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-2xs card-accessible">
          <div className="flex items-center justify-between text-gray-400 mb-2">
            <span className="text-xs font-medium">Pending Review</span>
            <Clock className="w-4 h-4 text-amber-500" aria-hidden="true" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-600 dark:text-amber-400">{pendingCount}</div>
          <span className="text-[10px] text-gray-400 block mt-1">Under verification</span>
        </div>

        {/* Completed */}
        <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-2xs card-accessible">
          <div className="flex items-center justify-between text-gray-400 mb-2">
            <span className="text-xs font-medium">Completed</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" aria-hidden="true" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-emerald-600 dark:text-emerald-400">{completedCount}</div>
          <span className="text-[10px] text-gray-400 block mt-1">Disbursed / Done</span>
        </div>

        {/* AI Assisted */}
        <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-2xs card-accessible">
          <div className="flex items-center justify-between text-gray-400 mb-2">
            <span className="text-xs font-medium">AI Journeys</span>
            <Bot className="w-4 h-4 text-purple-600" aria-hidden="true" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-purple-600 dark:text-purple-400">84%</div>
          <span className="text-[10px] text-gray-400 block mt-1">1,192 sessions (demo)</span>
        </div>

        {/* A11y Usage */}
        <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-2xs card-accessible">
          <div className="flex items-center justify-between text-gray-400 mb-2">
            <span className="text-xs font-medium">A11y Usage</span>
            <Eye className="w-4 h-4 text-cyan-600" aria-hidden="true" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-cyan-600 dark:text-cyan-400">38%</div>
          <span className="text-[10px] text-gray-400 block mt-1">Voice & high contrast</span>
        </div>
      </div>

      {/* Global Feedback Banner */}
      {updateFeedback && (
        <div
          role="status"
          className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-sm font-semibold flex items-center justify-between animate-in fade-in"
        >
          <span>{updateFeedback}</span>
          <button
            type="button"
            onClick={() => setUpdateFeedback(null)}
            className="text-xs underline text-emerald-800 dark:text-emerald-300"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Applications Management Table Section */}
      <div className="bg-white dark:bg-gray-800 rounded-3xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden card-accessible">
        {/* Table Filter Controls */}
        <div className="p-5 border-b border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gray-50/50 dark:bg-gray-900/40">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3" aria-hidden="true" />
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder="Search by ID, citizen name, or scheme..."
              aria-label="Filter applications"
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 focus:outline-hidden focus:border-blue-600"
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-gray-400" aria-hidden="true" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              aria-label="Filter by application status"
              className="text-xs font-semibold py-2 px-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 focus:outline-hidden focus:border-blue-600"
            >
              <option value="All">All Statuses ({applications.length})</option>
              <option value="Submitted">Submitted</option>
              <option value="Documents Received">Documents Received</option>
              <option value="Department Review">Department Review</option>
              <option value="Decision">Decision</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-gray-100/70 dark:bg-gray-900/60 text-gray-500 uppercase tracking-wider text-[11px] border-b border-gray-200 dark:border-gray-700">
              <tr>
                <th className="py-3.5 px-4 font-bold">Reference ID</th>
                <th className="py-3.5 px-4 font-bold">Citizen Applicant</th>
                <th className="py-3.5 px-4 font-bold">Service Scheme</th>
                <th className="py-3.5 px-4 font-bold">Date</th>
                <th className="py-3.5 px-4 font-bold">Current Status</th>
                <th className="py-3.5 px-4 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {filteredApps.map((app) => {
                const isAnitha = app.id === 'SV-2026-001247';

                return (
                  <tr
                    key={app.id}
                    className={`hover:bg-blue-50/40 dark:hover:bg-blue-950/20 transition-colors ${
                      isAnitha ? 'bg-amber-50/30 dark:bg-amber-950/10' : ''
                    }`}
                  >
                    <td className="py-3.5 px-4 font-mono font-bold text-blue-700 dark:text-blue-300">
                      {app.id}
                      {isAnitha && (
                        <span className="ml-1.5 px-1.5 py-0.2 rounded text-[9px] bg-amber-200 text-amber-900 font-sans uppercase font-bold">
                          Demo Persona
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-gray-900 dark:text-white">
                      {app.citizenName}
                      <span className="block text-[11px] text-gray-400 font-normal">
                        {app.phone} • {app.state}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-gray-700 dark:text-gray-300 max-w-[220px] truncate">
                      {app.serviceName}
                    </td>
                    <td className="py-3.5 px-4 text-gray-500 whitespace-nowrap">
                      {app.submissionDate}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                          app.status === 'Completed'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                            : app.status === 'Department Review'
                            ? 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300'
                            : app.status === 'Decision'
                            ? 'bg-cyan-100 text-cyan-800 dark:bg-cyan-950/60 dark:text-cyan-300'
                            : app.status === 'Documents Received'
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                        }`}
                      >
                        {app.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => handleOpenDetail(app)}
                        className="touch-target px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs transition-colors shadow-2xs"
                      >
                        Inspect & Update
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Application Detail Inspection & Status Updater Modal */}
      {selectedApp && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="app-detail-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs"
          onClick={(e) => {
            if (e.target === e.currentTarget) setSelectedApp(null);
          }}
        >
          <div className="w-full max-w-2xl bg-white dark:bg-gray-900 rounded-3xl shadow-2xl border border-gray-200 dark:border-gray-700 overflow-hidden max-h-[92vh] flex flex-col card-accessible animate-in fade-in">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-800 bg-gray-50/70 dark:bg-gray-800/60">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 block">
                  Reference: {selectedApp.id}
                </span>
                <h2 id="app-detail-title" className="text-lg font-bold text-gray-900 dark:text-white">
                  {selectedApp.serviceName}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setSelectedApp(null)}
                aria-label="Close detail modal"
                className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto space-y-6">
              {/* Citizen Overview */}
              <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="text-gray-400 block text-[11px]">Applicant</span>
                  <span className="font-bold text-gray-900 dark:text-white">{selectedApp.citizenName}</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[11px]">Phone</span>
                  <span className="font-bold text-gray-900 dark:text-white">{selectedApp.phone}</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[11px]">Age / State</span>
                  <span className="font-bold text-gray-900 dark:text-white">{selectedApp.age} yrs • {selectedApp.state}</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[11px]">Submitted</span>
                  <span className="font-bold text-gray-900 dark:text-white">{selectedApp.submissionDate}</span>
                </div>
              </div>

              {/* Uploaded Documents List */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 flex items-center gap-1.5">
                  <FileCheck2 className="w-4 h-4 text-blue-600" aria-hidden="true" />
                  <span>Submitted Digital Documents ({selectedApp.uploadedDocuments.length})</span>
                </h3>
                <div className="divide-y divide-gray-100 dark:divide-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl overflow-hidden bg-white dark:bg-gray-900">
                  {selectedApp.uploadedDocuments.map((doc: { docName: string; fileName: string }, idx: number) => (
                    <div key={idx} className="p-3 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-gray-800 dark:text-gray-200 block truncate max-w-sm">
                          {doc.docName}
                        </span>
                        <span className="text-[11px] text-gray-400 font-mono">{doc.fileName}</span>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                        Verified Proof
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Official Status Update Form */}
              <form onSubmit={handleStatusUpdate} className="p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-blue-950 dark:text-blue-200 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-blue-600" aria-hidden="true" />
                    <span>Update Application Status</span>
                  </h3>
                  <span className="text-[10px] text-blue-700 dark:text-blue-300 font-semibold">
                    Automatically dispatches notification to citizen
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      New Status Stage:
                    </label>
                    <select
                      value={newStatus}
                      onChange={(e) => setNewStatus(e.target.value as any)}
                      className="w-full p-2.5 rounded-xl border border-blue-300 dark:border-blue-800 bg-white dark:bg-gray-900 text-xs font-bold text-gray-900 dark:text-white focus:outline-hidden"
                    >
                      <option value="Submitted">1. Submitted</option>
                      <option value="Documents Received">2. Documents Received</option>
                      <option value="Department Review">3. Department Review</option>
                      <option value="Decision">4. Decision (Sanction Approved)</option>
                      <option value="Completed">5. Completed (DBT Disbursed)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      Official Remarks / Notes:
                    </label>
                    <input
                      type="text"
                      value={statusNote}
                      onChange={(e) => setStatusNote(e.target.value)}
                      placeholder="e.g. Sanction approved by District Welfare Officer."
                      className="w-full p-2.5 rounded-xl border border-blue-300 dark:border-blue-800 bg-white dark:bg-gray-900 text-xs text-gray-900 dark:text-white focus:outline-hidden"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => handleSendCustomNotification(selectedApp)}
                    className="text-xs text-blue-700 dark:text-blue-300 hover:underline font-semibold"
                  >
                    + Send Custom Ping Notification
                  </button>

                  <button
                    type="submit"
                    className="touch-target px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition-colors flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Save Status & Notify Citizen</span>
                  </button>
                </div>
              </form>

              {/* History Notes Log */}
              {selectedApp.notes && selectedApp.notes.length > 0 && (
                <div className="space-y-1.5">
                  <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                    Internal Case Notes
                  </h4>
                  <div className="space-y-1 text-xs text-gray-600 dark:text-gray-400">
                    {selectedApp.notes.map((n: string, i: number) => (
                      <div key={i} className="p-2 rounded-xl bg-gray-50 dark:bg-gray-800/60 border border-gray-100 dark:border-gray-800">
                        • {n}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/50 flex justify-between items-center">
              <Link
                to={`/track?id=${encodeURIComponent(selectedApp.id)}`}
                className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
              >
                <span>View Citizen Tracking Screen</span>
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </Link>

              <button
                type="button"
                onClick={() => setSelectedApp(null)}
                className="px-4 py-2 rounded-xl bg-gray-200 dark:bg-gray-700 text-xs font-semibold text-gray-800 dark:text-gray-200"
              >
                Close Window
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
};
