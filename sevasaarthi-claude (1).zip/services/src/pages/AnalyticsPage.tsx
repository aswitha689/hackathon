import React from 'react';
import { Link } from 'react-router-dom';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  BarChart3,
  Languages,
  Eye,
  HelpCircle,
  TrendingUp,
} from 'lucide-react';

export const AnalyticsPage: React.FC = () => {
  // 1. Service Usage Data (Simulated Demo Data)
  const serviceUsageData = [
    { name: 'Scholarship', full: 'Post-Matric Scholarship', applications: 580, fill: '#2563eb' },
    { name: 'Farmer Aid', full: 'Rythu Farmer Grant', applications: 360, fill: '#059669' },
    { name: 'Senior Pension', full: 'Elderly Pension (Aasara)', applications: 250, fill: '#7c3aed' },
    { name: 'Certificate', full: 'Income Certificate', applications: 195, fill: '#0891b2' },
    { name: 'College Aid', full: 'Higher Education Aid', applications: 145, fill: '#ea580c' },
  ];

  // 2. Language Distribution Data
  const languageData = [
    { name: 'Telugu (తెలుగు)', value: 52, color: '#2563eb' },
    { name: 'English (EN)', value: 28, color: '#059669' },
    { name: 'Hindi (हिंदी)', value: 20, color: '#ea580c' },
  ];

  // 3. Accessibility Adoption Data
  const a11yData = [
    { feature: 'Text Scaling (Large/XL)', users: 582, fill: '#0284c7' },
    { feature: 'Voice Read Aloud', users: 398, fill: '#7c3aed' },
    { feature: 'High Contrast Mode', users: 270, fill: '#059669' },
    { feature: 'Data Saver Mode', users: 170, fill: '#d97706' },
  ];

  // 4. Citizen Application Funnel
  const funnelData = [
    { stage: '1. Discovery', citizens: 1420, rate: '100%' },
    { stage: '2. Eligibility Check', citizens: 1150, rate: '81%' },
    { stage: '3. Doc Checklist', citizens: 890, rate: '63%' },
    { stage: '4. Submitted', citizens: 760, rate: '54%' },
    { stage: '5. Sanctioned', citizens: 610, rate: '43%' },
  ];

  // 5. Most Common Citizen Inquiries
  const commonInquiries = [
    { query: 'How to obtain college bonafide letter for scholarship?', count: 284, category: 'Education' },
    { query: 'Can I apply for pension if grandfather is 62?', count: 215, category: 'Senior Citizens' },
    { query: 'What is the MeeSeva income certificate fee & validity?', count: 189, category: 'Certificates' },
    { query: 'Are tenant farmers eligible for crop seed grant?', count: 142, category: 'Farmer Services' },
    { query: 'Does Aadhaar have to be seeded to bank for DBT credit?', count: 128, category: 'General' },
  ];

  return (
    <main id="main-content" className="flex-1 py-8 px-4 sm:px-6 max-w-7xl mx-auto w-full space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 dark:border-gray-800 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-purple-100 text-purple-800 dark:bg-purple-900/60 dark:text-purple-300">
              Citizen Insights
            </span>
            <span className="text-xs text-amber-700 dark:text-amber-300 font-semibold bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 px-2 py-0.5 rounded">
              Simulated Demo Data
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white">
            SevaSaarthi Analytics Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
            Real-time telemetry on service demand, multilingual engagement, and accessibility feature adoption.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Link
            to="/admin"
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors"
          >
            ← Admin Portal
          </Link>
          <Link
            to="/"
            className="px-4 py-2 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-200 text-xs font-semibold hover:bg-gray-200 transition-colors"
          >
            Citizen Home
          </Link>
        </div>
      </div>

      {/* Grid of Visual Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Service Demand Usage */}
        <div className="p-6 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm card-accessible space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" aria-hidden="true" />
              <h2 className="text-sm font-bold text-gray-900 dark:text-white">
                Service Demand (Total Applications)
              </h2>
            </div>
            <span className="text-[10px] uppercase font-bold text-gray-400">Demo Data</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={serviceUsageData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  formatter={(val: any) => [`${val} Applications`, 'Volume']}
                  labelFormatter={(name) => `Scheme: ${name}`}
                  contentStyle={{ borderRadius: '12px', fontSize: '12px' }}
                />
                <Bar dataKey="applications" radius={[6, 6, 0, 0]}>
                  {serviceUsageData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Language Usage Distribution */}
        <div className="p-6 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm card-accessible space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Languages className="w-5 h-5 text-indigo-600" aria-hidden="true" />
              <h2 className="text-sm font-bold text-gray-900 dark:text-white">
                Multilingual Citizen Adoption
              </h2>
            </div>
            <span className="text-[10px] uppercase font-bold text-gray-400">Demo Data</span>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={languageData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                  label={({ name, value }: any) => `${String(name || '').split(' ')[0]} ${value}%`}
                >
                  {languageData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [`${val}% of citizens`, 'Share']}
                  contentStyle={{ borderRadius: '12px', fontSize: '12px' }}
                />
                <Legend iconType="circle" />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Accessibility Features Usage */}
        <div className="p-6 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm card-accessible space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-cyan-600" aria-hidden="true" />
              <h2 className="text-sm font-bold text-gray-900 dark:text-white">
                Accessibility Feature Utilization
              </h2>
            </div>
            <span className="text-[10px] uppercase font-bold text-gray-400">Demo Data</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart layout="vertical" data={a11yData} margin={{ top: 10, right: 20, left: 40, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis type="number" tick={{ fontSize: 11 }} />
                <YAxis dataKey="feature" type="category" tick={{ fontSize: 11 }} width={120} />
                <Tooltip
                  formatter={(val: any) => [`${val} Citizens Enabled`, 'Users']}
                  contentStyle={{ borderRadius: '12px', fontSize: '12px' }}
                />
                <Bar dataKey="users" radius={[0, 6, 6, 0]}>
                  {a11yData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Application Funnel */}
        <div className="p-6 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm card-accessible space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-600" aria-hidden="true" />
              <h2 className="text-sm font-bold text-gray-900 dark:text-white">
                Application Journey Conversion Funnel
              </h2>
            </div>
            <span className="text-[10px] uppercase font-bold text-gray-400">Demo Data</span>
          </div>

          <div className="space-y-3 pt-2">
            {funnelData.map((f, i) => (
              <div key={i} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-gray-700 dark:text-gray-300">{f.stage}</span>
                  <span className="text-gray-900 dark:text-white font-bold">
                    {f.citizens} ({f.rate})
                  </span>
                </div>
                <div className="w-full bg-gray-100 dark:bg-gray-700 h-3 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full transition-all"
                    style={{ width: f.rate }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Common Citizen Questions Section */}
      <div className="p-6 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm card-accessible space-y-4">
        <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-700/60 pb-3">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-purple-600" aria-hidden="true" />
            <h2 className="text-base font-bold text-gray-900 dark:text-white">
              Most Frequently Asked Citizen Inquiries (AI Assistant Logs)
            </h2>
          </div>
          <span className="text-[10px] uppercase font-bold text-gray-400">Seeded Demo Data</span>
        </div>

        <div className="divide-y divide-gray-100 dark:divide-gray-800">
          {commonInquiries.map((q, idx) => (
            <div key={idx} className="py-3 flex items-center justify-between text-xs sm:text-sm">
              <div className="space-y-0.5">
                <p className="font-semibold text-gray-800 dark:text-gray-200">
                  "{q.query}"
                </p>
                <span className="text-[11px] text-gray-400">Category: {q.category}</span>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 font-bold text-xs shrink-0">
                {q.count} inquiries
              </span>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
};
