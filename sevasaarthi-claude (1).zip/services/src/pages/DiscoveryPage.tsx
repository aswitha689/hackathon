import React, { useMemo } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import {
  Sparkles,
  ArrowRight,
  Clock,
  Banknote,
  Building2,
  FileText,
  Volume2,
  ArrowLeft,
  CheckCircle2,
  HelpCircle,
  SearchX,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { matchServices } from '../utils/matcher';
import { FloatingAIAssistant } from '../components/FloatingAIAssistant';
import type { Service } from '../types';

export const DiscoveryPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const categoryParam = searchParams.get('category') || '';

  const { language, t, getLocalized } = useLanguage();
  const { speakText, settings } = useAccessibility();
  const navigate = useNavigate();

  // Match services using NLP utility
  const result = useMemo(() => {
    return matchServices(query, categoryParam);
  }, [query, categoryParam]);

  const topIntentTitle = result.detectedIntentTitle[language] || result.detectedIntentTitle.en;

  const handleReadCard = (service: Service, matchReason: string) => {
    const text = `${getLocalized(service.name)}. ${matchReason}. ${getLocalized(
      service.department
    )}. ${getLocalized(service.eligibilitySummary)}`;
    speakText(text, language);
  };

  return (
    <main id="main-content" className="flex-1 py-8 px-4 sm:px-6 max-w-6xl mx-auto w-full">
      {/* Back button & Breadcrumb */}
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>{t('common.back')}</span>
        </Link>
        <span className="text-xs px-2.5 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-semibold border border-blue-200 dark:border-blue-900">
          Step 1 of 5: Discovery
        </span>
      </div>

      {/* Understood Intent Banner */}
      <div className="mb-8 p-6 rounded-3xl bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-950/40 dark:to-gray-900 border border-blue-100 dark:border-blue-900/60 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white dark:bg-gray-800 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 text-xs font-bold">
              {result.matches.length > 0 ? (
                <>
                  <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>We understood your need</span>
                </>
              ) : (
                <>
                  <SearchX className="w-3.5 h-3.5 text-amber-500" aria-hidden="true" />
                  <span>Search Result</span>
                </>
              )}
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white">
              {topIntentTitle}
            </h1>
            {query && (
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">
                Based on your inquiry: <span className="font-semibold italic">"{query}"</span>
              </p>
            )}
          </div>
          <div className="text-left sm:text-right">
            <span className="text-xs text-gray-500 dark:text-gray-400 block">Matched Services</span>
            <span className="text-xl font-bold text-gray-900 dark:text-white">
              {result.matches.length} Schemes Available
            </span>
          </div>
        </div>
      </div>

      {/* Preliminary Notice Reminder */}
      <div className="mb-6 p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 flex items-start gap-2.5 text-xs text-amber-900 dark:text-amber-200">
        <HelpCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" aria-hidden="true" />
        <span>{t('preliminaryNotice')}</span>
      </div>

      {/* Service Cards Grid OR Honest Zero-Match Display */}
      {result.matches.length === 0 ? (
        <div className="bg-white dark:bg-gray-800 rounded-3xl border border-gray-200 dark:border-gray-700 p-8 sm:p-12 text-center space-y-6 card-accessible shadow-sm">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
            <HelpCircle className="w-8 h-8" />
          </div>
          <div className="max-w-lg mx-auto space-y-2">
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
              Information Not Available in Demo Database
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
              We could not find an exact public scheme directly matching: <span className="font-semibold italic">"{query}"</span>.
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Per our verified data rules, we never invent schemes. Please browse verified citizen categories below or ask our AI assistant for guidance.
            </p>
          </div>

          {/* Quick Categories Browse */}
          <div className="pt-6 border-t border-gray-100 dark:border-gray-700/60 max-w-2xl mx-auto">
            <p className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">
              Explore Verified Citizen Categories:
            </p>
            <div className="flex flex-wrap justify-center gap-2.5">
              <Link
                to="/discovery?category=disability-services"
                className="px-4 py-2.5 rounded-2xl bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 text-xs font-semibold text-blue-800 dark:text-blue-200 transition-colors border border-blue-200 dark:border-blue-900"
              >
                ♿ Disability & Accident Relief
              </Link>
              <Link
                to="/discovery?category=education"
                className="px-4 py-2.5 rounded-2xl bg-gray-100 hover:bg-blue-50 dark:bg-gray-700 dark:hover:bg-blue-950 text-xs font-semibold text-gray-800 dark:text-gray-200 transition-colors"
              >
                🎓 Education & Scholarships
              </Link>
              <Link
                to="/discovery?category=housing"
                className="px-4 py-2.5 rounded-2xl bg-gray-100 hover:bg-blue-50 dark:bg-gray-700 dark:hover:bg-blue-950 text-xs font-semibold text-gray-800 dark:text-gray-200 transition-colors"
              >
                🏠 Housing & Shelter
              </Link>
              <Link
                to="/discovery?category=farmer-services"
                className="px-4 py-2.5 rounded-2xl bg-gray-100 hover:bg-blue-50 dark:bg-gray-700 dark:hover:bg-blue-950 text-xs font-semibold text-gray-800 dark:text-gray-200 transition-colors"
              >
                🌾 Farmer Grants
              </Link>
              <Link
                to="/discovery?category=senior-citizens"
                className="px-4 py-2.5 rounded-2xl bg-gray-100 hover:bg-blue-50 dark:bg-gray-700 dark:hover:bg-blue-950 text-xs font-semibold text-gray-800 dark:text-gray-200 transition-colors"
              >
                👴 Senior Citizen Pension
              </Link>
              <Link
                to="/discovery?category=certificates"
                className="px-4 py-2.5 rounded-2xl bg-gray-100 hover:bg-blue-50 dark:bg-gray-700 dark:hover:bg-blue-950 text-xs font-semibold text-gray-800 dark:text-gray-200 transition-colors"
              >
                📄 Certificates
              </Link>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {result.matches.map(({ service, matchReason }) => {
            const reasonText = matchReason[language] || matchReason.en;

            return (
              <article
                key={service.id}
                className="bg-white dark:bg-gray-800 rounded-3xl border border-gray-200 dark:border-gray-700 p-6 sm:p-8 shadow-sm hover:shadow-md transition-all card-accessible"
              >
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6">
                  {/* Left details */}
                  <div className="flex-1 space-y-4">
                    {/* Department & Read Aloud */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 dark:text-gray-400">
                        <Building2 className="w-4 h-4 text-gray-400" aria-hidden="true" />
                        <span>{getLocalized(service.department)}</span>
                      </div>

                      {settings.readAloudEnabled && (
                        <button
                          type="button"
                          onClick={() => handleReadCard(service, reasonText)}
                          aria-label={`Read aloud details for ${getLocalized(service.name)}`}
                          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 transition-colors"
                        >
                          <Volume2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" aria-hidden="true" />
                          <span>{t('common.readAloud')}</span>
                        </button>
                      )}
                    </div>

                    {/* Title & Description */}
                    <div>
                      <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white mb-2">
                        {getLocalized(service.name)}
                      </h2>
                      <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
                        {getLocalized(service.description)}
                      </p>
                    </div>

                    {/* "Why this matches you" Highlight Badge */}
                    <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60">
                      <div className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" aria-hidden="true" />
                        <div>
                          <span className="text-xs font-bold text-emerald-900 dark:text-emerald-300 uppercase tracking-wider block mb-0.5">
                            Why this matches you:
                          </span>
                          <p className="text-xs sm:text-sm text-emerald-950 dark:text-emerald-200 font-medium">
                            {reasonText}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Eligibility Summary */}
                    <div className="text-xs sm:text-sm space-y-1">
                      <span className="font-semibold text-gray-900 dark:text-white">
                        Eligibility Overview:
                      </span>
                      <p className="text-gray-600 dark:text-gray-400">
                        {getLocalized(service.eligibilitySummary)}
                      </p>
                    </div>

                    {/* Metadata Chips: Time, Fee, Method */}
                    <div className="flex flex-wrap gap-2 pt-1 text-xs">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-gray-700/60 text-gray-700 dark:text-gray-300 font-medium">
                        <Clock className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" aria-hidden="true" />
                        <span>{getLocalized(service.processingInformation.timeEstimate)}</span>
                      </span>
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-gray-700/60 text-gray-700 dark:text-gray-300 font-medium">
                        <Banknote className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                        <span>{getLocalized(service.processingInformation.fees)}</span>
                      </span>
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-gray-700/60 text-gray-700 dark:text-gray-300 font-medium">
                        <FileText className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" aria-hidden="true" />
                        <span>Online Guided Portal</span>
                      </span>
                    </div>
                  </div>

                  {/* Right CTA card */}
                  <div className="lg:w-64 flex flex-col justify-between p-5 rounded-2xl bg-gray-50 dark:bg-gray-900/60 border border-gray-200 dark:border-gray-700 shrink-0 space-y-4">
                    <div>
                      <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block mb-1">
                        Application Method
                      </span>
                      <span className="text-sm font-bold text-gray-800 dark:text-gray-200 block">
                        4-Step Digital Form
                      </span>
                      <ul className="text-xs text-gray-500 dark:text-gray-400 space-y-1 mt-2">
                        <li>• Step 1: Personal Details</li>
                        <li>• Step 2: Eligibility Check</li>
                        <li>• Step 3: Document Upload</li>
                        <li>• Step 4: Submission</li>
                      </ul>
                    </div>

                    <button
                      type="button"
                      onClick={() => navigate(`/wizard/${service.id}`)}
                      className="touch-target w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-sm transition-colors flex items-center justify-center gap-2"
                    >
                      <span>{t('common.checkEligibility')}</span>
                      <ArrowRight className="w-4 h-4" aria-hidden="true" />
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Floating AI Assistant for contextual questions */}
      <FloatingAIAssistant currentService={result.matches[0]?.service} contextStage="Discovery" />
    </main>
  );
};
