import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  Upload,
  FileCheck,
  CheckCircle2,
  Trash2,
  Sparkles,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import rawServices from '../data/services.json';
import { FloatingAIAssistant } from '../components/FloatingAIAssistant';
import type { Service } from '../types';

const services = rawServices as unknown as Service[];

export interface UploadedDocRecord {
  docId: string;
  docName: string;
  fileName: string;
  uploadTime: string;
}

export const DocumentChecklistPage: React.FC = () => {
  const { serviceId } = useParams<{ serviceId: string }>();
  const { getLocalized } = useLanguage();
  const navigate = useNavigate();

  const service = services.find((s) => s.id === serviceId) || services[0];

  // Uploaded docs state mapped by docId
  const [uploads, setUploads] = useState<Record<string, UploadedDocRecord>>(() => {
    try {
      const saved = localStorage.getItem(`sevasaarthi_uploads_${service.id}`);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const saveUploads = (updated: Record<string, UploadedDocRecord>) => {
    setUploads(updated);
    try {
      localStorage.setItem(`sevasaarthi_uploads_${service.id}`, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save uploads', e);
    }
  };

  const handleSimulatedUpload = (docId: string, docName: string, defaultName?: string) => {
    const fileName = defaultName || `${docId}_sample_scan.pdf`;
    const updated = {
      ...uploads,
      [docId]: {
        docId,
        docName,
        fileName,
        uploadTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    };
    saveUploads(updated);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, docId: string, docName: string) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const updated = {
        ...uploads,
        [docId]: {
          docId,
          docName,
          fileName: file.name,
          uploadTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      };
      saveUploads(updated);
    }
  };

  const handleRemove = (docId: string) => {
    const next = { ...uploads };
    delete next[docId];
    saveUploads(next);
  };

  // Pre-load all documents for Anitha demo
  const handlePreloadAnitha = () => {
    const demoDocs: Record<string, UploadedDocRecord> = {
      doc_college_id: {
        docId: 'doc_college_id',
        docName: 'College Bonafide / Admission Allotment Letter',
        fileName: 'anitha_bonafide_2026.pdf',
        uploadTime: 'Just now',
      },
      doc_income_cert: {
        docId: 'doc_income_cert',
        docName: 'Income Certificate (MeeSeva / Tehsil)',
        fileName: 'income_cert_2026.pdf',
        uploadTime: 'Just now',
      },
      doc_marksheet: {
        docId: 'doc_marksheet',
        docName: 'Previous Qualifying Marksheet (10th/Inter)',
        fileName: 'inter_marksheet_gradeA.pdf',
        uploadTime: 'Just now',
      },
      doc_bank_passbook: {
        docId: 'doc_bank_passbook',
        docName: 'Student Bank Passbook Copy',
        fileName: 'bank_passbook_sbi.pdf',
        uploadTime: 'Just now',
      },
    };
    saveUploads(demoDocs);
  };

  // Required docs counter
  const requiredDocs = service.documents.filter((d) => d.required);
  const uploadedRequiredCount = requiredDocs.filter((d) => Boolean(uploads[d.id])).length;
  const isAllRequiredUploaded = uploadedRequiredCount === requiredDocs.length;

  return (
    <main id="main-content" className="flex-1 py-8 px-4 sm:px-6 max-w-4xl mx-auto w-full">
      {/* Header & Back */}
      <div className="mb-6 flex items-center justify-between">
        <Link
          to={`/wizard/${service.id}`}
          className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-gray-600 dark:text-gray-300 hover:text-blue-600"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Back to Eligibility</span>
        </Link>
        <span className="text-xs px-2.5 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-semibold border border-blue-200 dark:border-blue-900">
          Step 3 of 5: Document Checklist
        </span>
      </div>

      {/* Service Context Header */}
      <div className="mb-6 p-6 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 card-accessible">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 block mb-1">
            Service Document Checklist
          </span>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
            {getLocalized(service.name)}
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">
            Keep clear digital copies ready. Accepted formats: PDF, JPG, PNG (Max 5MB per file).
          </p>
        </div>

        {/* Demo Fast-Action Pre-loader for Anitha Persona */}
        <button
          type="button"
          onClick={handlePreloadAnitha}
          className="shrink-0 inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/50 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 font-semibold text-xs hover:bg-amber-100 transition-colors shadow-2xs"
        >
          <Sparkles className="w-4 h-4 text-amber-600" aria-hidden="true" />
          <span>⚡ Auto-Attach Anitha's Demo Docs</span>
        </button>
      </div>

      {/* Progress Counter Banner */}
      <div className="mb-6 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/80 border border-gray-200 dark:border-gray-700 flex items-center justify-between text-xs sm:text-sm font-semibold">
        <div className="flex items-center gap-2">
          <FileCheck className="w-5 h-5 text-blue-600 dark:text-blue-400" aria-hidden="true" />
          <span>
            {uploadedRequiredCount} of {requiredDocs.length} Mandatory Documents Attached
          </span>
        </div>
        <span
          className={`px-3 py-1 rounded-full text-xs font-bold ${
            isAllRequiredUploaded
              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
              : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
          }`}
        >
          {isAllRequiredUploaded ? '✓ Ready for Application' : 'Pending Documents'}
        </span>
      </div>

      {/* Document Items List */}
      <div className="space-y-4">
        {service.documents.map((doc) => {
          const uploaded = uploads[doc.id];
          const isUploaded = Boolean(uploaded);

          return (
            <div
              key={doc.id}
              className={`p-5 rounded-2xl border transition-all card-accessible ${
                isUploaded
                  ? 'border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/20 dark:bg-emerald-950/10'
                  : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        doc.required
                          ? 'bg-red-100 text-red-700 dark:bg-red-950/60 dark:text-red-300'
                          : 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
                      }`}
                    >
                      {doc.required ? 'Mandatory' : 'Optional'}
                    </span>
                    <h3 className="text-sm sm:text-base font-bold text-gray-900 dark:text-white">
                      {getLocalized(doc.name)}
                    </h3>
                  </div>
                  <p className="text-xs text-gray-600 dark:text-gray-300">
                    {getLocalized(doc.description)}
                  </p>

                  {/* Upload status indicator */}
                  {isUploaded && (
                    <div className="inline-flex items-center gap-1.5 text-xs text-emerald-700 dark:text-emerald-300 font-semibold pt-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" aria-hidden="true" />
                      <span>Attached: {uploaded.fileName}</span>
                      <span className="text-gray-400">({uploaded.uploadTime})</span>
                    </div>
                  )}
                </div>

                {/* Upload Action Buttons */}
                <div className="flex items-center gap-2 shrink-0">
                  {isUploaded ? (
                    <button
                      type="button"
                      onClick={() => handleRemove(doc.id)}
                      aria-label={`Remove ${getLocalized(doc.name)}`}
                      className="p-2.5 rounded-xl border border-red-200 dark:border-red-900 hover:bg-red-50 text-red-600 dark:text-red-400 transition-colors"
                      title="Remove file"
                    >
                      <Trash2 className="w-4 h-4" aria-hidden="true" />
                    </button>
                  ) : (
                    <div className="flex items-center gap-2">
                      {/* Hidden file input */}
                      <label className="cursor-pointer touch-target px-3.5 py-2 rounded-xl bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 hover:border-blue-500 text-gray-700 dark:text-gray-200 text-xs font-semibold flex items-center gap-1.5 shadow-2xs">
                        <Upload className="w-3.5 h-3.5 text-blue-600" aria-hidden="true" />
                        <span>Choose File</span>
                        <input
                          type="file"
                          className="sr-only"
                          onChange={(e) =>
                            handleFileChange(e, doc.id, getLocalized(doc.name))
                          }
                        />
                      </label>

                      {/* Mock upload button */}
                      <button
                        type="button"
                        onClick={() =>
                          handleSimulatedUpload(
                            doc.id,
                            getLocalized(doc.name),
                            doc.sampleName
                          )
                        }
                        className="touch-target px-3 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 hover:bg-blue-100 text-xs font-semibold transition-colors"
                      >
                        Simulate
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Navigation */}
      <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row items-center justify-between gap-4">
        <Link
          to={`/wizard/${service.id}`}
          className="text-xs sm:text-sm font-semibold text-gray-600 dark:text-gray-300 hover:text-blue-600"
        >
          ← Review Eligibility Answers
        </Link>

        <button
          type="button"
          onClick={() => navigate(`/apply/${service.id}`)}
          className="touch-target w-full sm:w-auto px-7 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-sm transition-colors flex items-center justify-center gap-2"
        >
          <span>Continue to Guided Application</span>
          <ArrowRight className="w-4 h-4" aria-hidden="true" />
        </button>
      </div>

      <FloatingAIAssistant currentService={service} contextStage="Document Checklist" />
    </main>
  );
};
