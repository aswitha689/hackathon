import React, { useState, useMemo } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Info,
  Building2,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import rawServices from '../data/services.json';
import { FloatingAIAssistant } from '../components/FloatingAIAssistant';
import type { Service } from '../types';

const services = rawServices as unknown as Service[];

export const EligibilityWizardPage: React.FC = () => {
  const { serviceId } = useParams<{ serviceId: string }>();
  const { t, getLocalized } = useLanguage();
  const navigate = useNavigate();

  const service = services.find((s) => s.id === serviceId) || services[0];

  // Wizard state: Smart defaults based on service category
  const [role, setRole] = useState<'student' | 'farmer' | 'senior' | 'woman' | 'pwd' | 'other'>(() => {
    if (service.category === 'disability-services') return 'pwd';
    if (service.category === 'farmer-services') return 'farmer';
    if (service.category === 'senior-citizens') return 'senior';
    return 'student';
  });
  const [age, setAge] = useState<number>(() => {
    if (service.category === 'senior-citizens') return 62;
    if (service.category === 'disability-services') return 32;
    return 20; // Anitha demo default
  });
  const [stateName, setStateName] = useState<string>('Andhra Pradesh');
  const [incomeBracket, setIncomeBracket] = useState<string>('under_2_5lakh');

  // Compute eligibility state (🟢 matched / 🟡 needs verification / 🔴 not met)
  const eligibilityEvaluation = useMemo(() => {
    // Disability Services
    if (service.category === 'disability-services' || service.id === 'disability-pension-assistive-aid') {
      if (role !== 'pwd') {
        return {
          status: 'needs_verification' as const,
          badgeColor: 'bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-900',
          title: '🟡 Medical Board Verification Needed',
          summary: 'To claim disability pension and artificial limb aids, certified disability (40%+ on SADAREM/UDID) or accident injury report is required.',
          canProceed: true,
        };
      }
      return {
        status: 'matched' as const,
        badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-900',
        title: '🟢 Preliminary Matched',
        summary: 'Preliminary qualifications met for Divyangjan pension, assistive limbs distribution, and accident disability relief.',
        canProceed: true,
      };
    }

    // Farmer Services
    if (service.category === 'farmer-services' || service.id === 'rythu-bharosa-farmer-aid') {
      if (role !== 'farmer') {
        return {
          status: 'not_met' as const,
          badgeColor: 'bg-red-100 text-red-800 border-red-200 dark:bg-red-950/60 dark:text-red-300',
          title: '🔴 Farmer Profile Required',
          summary: 'This agricultural grant requires the applicant to be a practicing farmer or cultivating landholder.',
          canProceed: false,
        };
      }
      return {
        status: 'matched' as const,
        badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300',
        title: '🟢 Preliminary Matched',
        summary: 'Preliminary qualifications met for agricultural input assistance and crop investment grant.',
        canProceed: true,
      };
    }

    // Post-matric scholarship (Anitha's scheme)
    if (service.id === 'post-matric-scholarship' || service.category === 'education') {
      if (role !== 'student') {
        return {
          status: 'not_met' as const,
          badgeColor: 'bg-red-100 text-red-800 border-red-200 dark:bg-red-950/60 dark:text-red-300 dark:border-red-900',
          title: '🔴 Criteria Not Satisfied',
          summary: 'This scheme is specifically for students enrolled in college or polytechnic courses.',
          canProceed: false,
        };
      }
      if (age > 30) {
        return {
          status: 'not_met' as const,
          badgeColor: 'bg-red-100 text-red-800 border-red-200 dark:bg-red-950/60 dark:text-red-300 dark:border-red-900',
          title: '🔴 Age Limit Exceeded',
          summary: 'The upper age limit for fresh post-matric college scholarships is 30 years.',
          canProceed: false,
        };
      }
      if (incomeBracket === 'above_2_5lakh') {
        return {
          status: 'needs_verification' as const,
          badgeColor: 'bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-900',
          title: '🟡 Needs Verification',
          summary: 'Income is near or above threshold. Special income verification by revenue officer is required.',
          canProceed: true,
        };
      }
      return {
        status: 'matched' as const,
        badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-900',
        title: '🟢 Preliminary Matched',
        summary: 'Congratulations! You satisfy all preliminary criteria for tuition reimbursement and college aid.',
        canProceed: true,
      };
    }

    // Senior citizen pension
    if (service.id === 'senior-citizen-pension' || service.category === 'senior-citizens') {
      if (age < 60) {
        return {
          status: 'not_met' as const,
          badgeColor: 'bg-red-100 text-red-800 border-red-200 dark:bg-red-950/60 dark:text-red-300',
          title: '🔴 Age Requirement Not Met',
          summary: 'Senior Citizen Pension requires applicant age to be 60 years or older.',
          canProceed: false,
        };
      }
      return {
        status: 'matched' as const,
        badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300',
        title: '🟢 Preliminary Matched',
        summary: 'Preliminary qualifications met for elderly social security pension.',
        canProceed: true,
      };
    }

    // Default match
    return {
      status: 'matched' as const,
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300',
      title: '🟢 Preliminary Matched',
      summary: 'You satisfy the basic profile requirements for this public service.',
      canProceed: true,
    };
  }, [service, role, age, incomeBracket]);

  return (
    <main id="main-content" className="flex-1 py-8 px-4 sm:px-6 max-w-4xl mx-auto w-full">
      {/* Header & Back */}
      <div className="mb-6 flex items-center justify-between">
        <Link
          to={`/discovery?category=${service.category}`}
          className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-gray-600 dark:text-gray-300 hover:text-blue-600"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Back to Discovery</span>
        </Link>
        <span className="text-xs px-2.5 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-semibold border border-blue-200 dark:border-blue-900">
          Step 2 of 5: Eligibility Wizard
        </span>
      </div>

      {/* Service Context Summary */}
      <div className="mb-8 p-5 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-2xs card-accessible">
        <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 dark:text-gray-400 mb-1">
          <Building2 className="w-3.5 h-3.5 text-blue-600" aria-hidden="true" />
          <span>{getLocalized(service.department)}</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
          {getLocalized(service.name)}
        </h1>
        <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-1">
          {getLocalized(service.eligibilitySummary)}
        </p>
      </div>

      {/* Preliminary Notice Required by Hard Rules */}
      <div className="mb-8 p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-xs text-blue-900 dark:text-blue-200 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" aria-hidden="true" />
        <div>
          <span className="font-bold block mb-0.5">Preliminary Guidance Notice:</span>
          <span>{t('preliminaryNotice')}</span>
        </div>
      </div>

      {/* 3-4 Relevant Questions Form */}
      <div className="space-y-6 bg-white dark:bg-gray-800 rounded-3xl border border-gray-200 dark:border-gray-700 p-6 sm:p-8 shadow-sm card-accessible">
        {/* Question 1: Who are you? */}
        <div className="space-y-3">
          <label className="block text-sm sm:text-base font-bold text-gray-900 dark:text-white">
            1. Who are you? <span className="text-xs font-normal text-gray-500">(Citizen Category)</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {[
              { id: 'student', label: 'College Student (Anitha)', icon: '🎓' },
              { id: 'farmer', label: 'Farmer / Cultivator', icon: '🌾' },
              { id: 'senior', label: 'Senior Citizen (60+)', icon: '👴' },
              { id: 'woman', label: 'Woman Beneficiary', icon: '👩' },
              { id: 'pwd', label: 'Person with Disability', icon: '♿' },
              { id: 'other', label: 'Other Citizen', icon: '👤' },
            ].map((item) => {
              const isSelected = role === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setRole(item.id as any)}
                  aria-pressed={isSelected}
                  className={`p-3.5 rounded-2xl border text-xs sm:text-sm font-semibold flex items-center gap-2.5 transition-all text-left touch-target ${
                    isSelected
                      ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/70 text-blue-800 dark:text-blue-200 ring-2 ring-blue-600/20'
                      : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-gray-300 bg-gray-50/50 dark:bg-gray-900/40'
                  }`}
                >
                  <span className="text-lg">{item.icon}</span>
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Question 2: Age */}
        <div className="space-y-2 pt-2 border-t border-gray-100 dark:border-gray-700/60">
          <div className="flex items-center justify-between">
            <label htmlFor="age-input" className="block text-sm font-bold text-gray-900 dark:text-white">
              2. What is your age?
            </label>
            <span className="text-sm font-bold text-blue-600 dark:text-blue-400">
              {age} years old
            </span>
          </div>
          <input
            id="age-input"
            type="range"
            min="15"
            max="80"
            value={age}
            onChange={(e) => setAge(Number(e.target.value))}
            className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-600"
          />
          <div className="flex justify-between text-[11px] text-gray-400">
            <span>15 yrs</span>
            <span className="font-semibold text-gray-600 dark:text-gray-300">Anitha Demo: 20 yrs</span>
            <span>80+ yrs</span>
          </div>
        </div>

        {/* Question 3: State / Region */}
        <div className="space-y-2 pt-2 border-t border-gray-100 dark:border-gray-700/60">
          <label htmlFor="state-select" className="block text-sm font-bold text-gray-900 dark:text-white">
            3. State of Residence:
          </label>
          <select
            id="state-select"
            value={stateName}
            onChange={(e) => setStateName(e.target.value)}
            className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm font-medium text-gray-900 dark:text-white focus:border-blue-600 focus:outline-hidden"
          >
            <option value="Andhra Pradesh">Andhra Pradesh</option>
            <option value="Telangana">Telangana</option>
            <option value="Karnataka">Karnataka</option>
            <option value="Tamil Nadu">Tamil Nadu</option>
            <option value="Other State">Other State / All India</option>
          </select>
        </div>

        {/* Question 4: Approx Family Income */}
        <div className="space-y-2 pt-2 border-t border-gray-100 dark:border-gray-700/60">
          <label htmlFor="income-select" className="block text-sm font-bold text-gray-900 dark:text-white">
            4. Approximate Family Annual Income:
          </label>
          <select
            id="income-select"
            value={incomeBracket}
            onChange={(e) => setIncomeBracket(e.target.value)}
            className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm font-medium text-gray-900 dark:text-white focus:border-blue-600 focus:outline-hidden"
          >
            <option value="under_1lakh">Below ₹1,00,000 (BPL / Very Low Income)</option>
            <option value="under_2_5lakh">₹1,00,000 to ₹2,50,000 (Eligible for Scholarship & Concessions)</option>
            <option value="above_2_5lakh">Above ₹2,50,000 (May require special category proof)</option>
          </select>
        </div>

        {/* Live Evaluation Result Card (🟢 / 🟡 / 🔴 with icons and text labels) */}
        <div
          role="region"
          aria-live="polite"
          className={`p-5 rounded-2xl border ${eligibilityEvaluation.badgeColor} space-y-2 transition-all`}
        >
          <div className="flex items-center gap-2">
            {eligibilityEvaluation.status === 'matched' && (
              <CheckCircle className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" aria-hidden="true" />
            )}
            {eligibilityEvaluation.status === 'needs_verification' && (
              <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" aria-hidden="true" />
            )}
            {eligibilityEvaluation.status === 'not_met' && (
              <XCircle className="w-5 h-5 text-red-600 dark:text-red-400 shrink-0" aria-hidden="true" />
            )}
            <h3 className="text-base font-bold">
              {eligibilityEvaluation.title}
            </h3>
          </div>
          <p className="text-xs sm:text-sm font-medium leading-relaxed">
            {eligibilityEvaluation.summary}
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
          <Link
            to={`/discovery?category=${service.category}`}
            className="px-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-xs sm:text-sm font-semibold text-gray-700 dark:text-gray-300 hover:bg-gray-50"
          >
            Choose Another Scheme
          </Link>

          <button
            type="button"
            disabled={!eligibilityEvaluation.canProceed}
            onClick={() => navigate(`/checklist/${service.id}`)}
            className="touch-target px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-sm shadow-sm transition-colors flex items-center gap-2"
          >
            <span>Proceed to Document Checklist</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>
      </div>

      <FloatingAIAssistant currentService={service} contextStage="Eligibility Wizard" />
    </main>
  );
};
