import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  Info,
  ShieldCheck,
  User,
  GraduationCap,
  FileCheck2,
  Send,
  Building2,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import rawServices from '../data/services.json';
import { saveApplication, generateApplicationId } from '../utils/storage';
import { FloatingAIAssistant } from '../components/FloatingAIAssistant';
import type { Service, ApplicationRecord } from '../types';

const services = rawServices as unknown as Service[];

export const GuidedApplicationPage: React.FC = () => {
  const { serviceId } = useParams<{ serviceId: string }>();
  const { getLocalized } = useLanguage();
  const navigate = useNavigate();

  const service = services.find((s) => s.id === serviceId) || services[0];

  // Active step (1 to 4)
  const [currentStep, setCurrentStep] = useState<number>(1);

  // Form Fields - Pre-fillable with Anitha persona
  const [citizenName, setCitizenName] = useState('Anitha');
  const [phone, setPhone] = useState('9876543210');
  const [age, setAge] = useState<number>(20);
  const [stateName, setStateName] = useState('Andhra Pradesh');
  const [district, setDistrict] = useState('East Godavari');
  const [collegeName, setCollegeName] = useState('Government Degree College, Rajahmundry');
  const [courseName, setCourseName] = useState('B.Sc Computer Science (2nd Year)');
  const [allotmentNo, setAllotmentNo] = useState('AP2026-EP8829');
  const [annualIncome, setAnnualIncome] = useState('₹1,40,000 / annum');
  const [bankAccount, setBankAccount] = useState('State Bank of India (Ending in •••• 4128)');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Autofill button for Anitha
  const handleAutofillAnitha = () => {
    setCitizenName('Anitha');
    setPhone('9876543210');
    setAge(20);
    setStateName('Andhra Pradesh');
    setDistrict('East Godavari');
    setCollegeName('Government Degree College, Rajahmundry');
    setCourseName('B.Sc Computer Science (2nd Year)');
    setAllotmentNo('AP2026-EP8829');
    setAnnualIncome('₹1,40,000 / annum');
    setBankAccount('State Bank of India (Ending in •••• 4128)');
  };

  const steps = [
    { number: 1, title: 'Personal Details', helper: 'Why we ask: To identify the applicant and verify residential jurisdiction.' },
    { number: 2, title: 'Eligibility Profile', helper: 'Why we ask: Required to ensure income and academic qualifications match state norms.' },
    { number: 3, title: 'Documents Review', helper: 'Why we ask: Essential proofs required by the Welfare Department before sanction.' },
    { number: 4, title: 'Review & Submit', helper: 'Why we ask: Verify your declaration before generating official tracking ID.' },
  ];

  // Submit Handler
  const handleSubmitApplication = async () => {
    setIsSubmitting(true);
    const newId = generateApplicationId();

    const applicationRecord: ApplicationRecord = {
      id: newId,
      serviceId: service.id,
      serviceName: getLocalized(service.name),
      citizenName,
      phone,
      age,
      state: stateName,
      status: 'Submitted',
      submissionDate: new Date().toLocaleString([], {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      lastUpdated: 'Just now',
      uploadedDocuments: service.documents.map((d) => ({
        docId: d.id,
        docName: getLocalized(d.name),
        fileName: `${citizenName.toLowerCase()}_${d.id}.pdf`,
        uploadTime: 'Ready',
      })),
      department: getLocalized(service.department),
      notes: ['Application received via SevaSaarthi citizen navigator.'],
    };

    await saveApplication(applicationRecord);

    setTimeout(() => {
      setIsSubmitting(false);
      navigate(`/submission/${newId}`);
    }, 600);
  };

  return (
    <main id="main-content" className="flex-1 py-8 px-4 sm:px-6 max-w-4xl mx-auto w-full">
      {/* Header & Back */}
      <div className="mb-6 flex items-center justify-between">
        <Link
          to={`/checklist/${service.id}`}
          className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-gray-600 dark:text-gray-300 hover:text-blue-600"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Back to Checklist</span>
        </Link>
        <span className="text-xs px-2.5 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-semibold border border-blue-200 dark:border-blue-900">
          Step 4 of 5: Guided Application
        </span>
      </div>

      {/* Progress Bar & Steps Header */}
      <div className="mb-8 p-6 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm card-accessible">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 block mb-1">
              Official Guided Application
            </span>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
              {getLocalized(service.name)}
            </h1>
          </div>

          {/* Quick Demo Pre-fill */}
          <button
            type="button"
            onClick={handleAutofillAnitha}
            className="shrink-0 inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs font-bold hover:bg-amber-100 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" aria-hidden="true" />
            <span>⚡ Fill Anitha Persona</span>
          </button>
        </div>

        {/* 4-Step Progress Indicator */}
        <div className="relative">
          <div className="overflow-hidden h-2 mb-4 text-xs flex rounded-full bg-gray-100 dark:bg-gray-700">
            <div
              style={{ width: `${(currentStep / 4) * 100}%` }}
              className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600 transition-all duration-300"
            />
          </div>

          <div className="grid grid-cols-4 text-center">
            {steps.map((st) => {
              const isPast = currentStep > st.number;
              const isCurrent = currentStep === st.number;
              return (
                <button
                  key={st.number}
                  type="button"
                  onClick={() => setCurrentStep(st.number)}
                  className={`text-xs font-semibold py-1 px-1 transition-colors ${
                    isCurrent
                      ? 'text-blue-600 dark:text-blue-400'
                      : isPast
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-gray-400'
                  }`}
                >
                  <span className="block text-[11px]">Step {st.number}</span>
                  <span className="truncate block hidden sm:block">{st.title}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* "Why we ask this" Helper Banner */}
      <div className="mb-6 p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-xs text-blue-900 dark:text-blue-200 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" aria-hidden="true" />
        <div>
          <span className="font-bold block mb-0.5">Step {currentStep}: {steps[currentStep - 1].title}</span>
          <p className="text-blue-800 dark:text-blue-300">{steps[currentStep - 1].helper}</p>
        </div>
      </div>

      {/* Step Form Container */}
      <div className="bg-white dark:bg-gray-800 rounded-3xl border border-gray-200 dark:border-gray-700 p-6 sm:p-8 shadow-sm card-accessible space-y-6">
        {/* STEP 1: Personal Details */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <h2 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <User className="w-4 h-4 text-blue-600" aria-hidden="true" />
              <span>Applicant Identification</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                  Full Name (as per SSC / College Record)
                </label>
                <input
                  type="text"
                  value={citizenName}
                  onChange={(e) => setCitizenName(e.target.value)}
                  className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-medium focus:border-blue-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                  Contact Mobile Number
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-medium focus:border-blue-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                  Age (in completed years)
                </label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-medium focus:border-blue-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                  State & District
                </label>
                <input
                  type="text"
                  value={`${stateName}, ${district}`}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-medium focus:border-blue-600 focus:outline-hidden"
                />
              </div>
            </div>

            {/* Simulated Aadhaar e-KYC demo banner */}
            <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between text-xs text-emerald-900 dark:text-emerald-200">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" aria-hidden="true" />
                <span>Simulated e-KYC Verification: <strong>Verified (Demo)</strong></span>
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded">
                Simulated Demo
              </span>
            </div>
          </div>
        )}

        {/* STEP 2: Eligibility Profile */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <h2 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-blue-600" aria-hidden="true" />
              <span>Academic & Economic Criteria Verification</span>
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                  Enrolled College / Institution Name
                </label>
                <input
                  type="text"
                  value={collegeName}
                  onChange={(e) => setCollegeName(e.target.value)}
                  className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-medium focus:border-blue-600 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    Course & Academic Year
                  </label>
                  <input
                    type="text"
                    value={courseName}
                    onChange={(e) => setCourseName(e.target.value)}
                    className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-medium focus:border-blue-600 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    Admission / Allotment Order No.
                  </label>
                  <input
                    type="text"
                    value={allotmentNo}
                    onChange={(e) => setAllotmentNo(e.target.value)}
                    className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-medium focus:border-blue-600 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    Certified Family Annual Income
                  </label>
                  <input
                    type="text"
                    value={annualIncome}
                    onChange={(e) => setAnnualIncome(e.target.value)}
                    className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-medium focus:border-blue-600 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                    DBT-Enabled Bank Account
                  </label>
                  <input
                    type="text"
                    value={bankAccount}
                    onChange={(e) => setBankAccount(e.target.value)}
                    className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-medium focus:border-blue-600 focus:outline-hidden"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: Documents Review */}
        {currentStep === 3 && (
          <div className="space-y-4">
            <h2 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <FileCheck2 className="w-4 h-4 text-blue-600" aria-hidden="true" />
              <span>Attached Documents Verification</span>
            </h2>

            <div className="divide-y divide-gray-100 dark:divide-gray-800">
              {service.documents.map((doc) => (
                <div key={doc.id} className="py-3 flex items-center justify-between text-xs sm:text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" aria-hidden="true" />
                    <span className="font-semibold text-gray-800 dark:text-gray-200">
                      {getLocalized(doc.name)}
                    </span>
                  </div>
                  <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-medium">
                    ✓ {citizenName.toLowerCase()}_{doc.id}.pdf
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STEP 4: Review & Submit */}
        {currentStep === 4 && (
          <div className="space-y-6">
            <h2 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-blue-600" aria-hidden="true" />
              <span>Final Citizen Declaration & Review</span>
            </h2>

            {/* Summary Card */}
            <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-900/60 border border-gray-200 dark:border-gray-700 text-xs sm:text-sm space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-gray-400 block text-[11px]">Applicant</span>
                  <span className="font-bold text-gray-900 dark:text-white">{citizenName} (Age: {age})</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[11px]">Contact Phone</span>
                  <span className="font-bold text-gray-900 dark:text-white">{phone}</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[11px]">Service Requested</span>
                  <span className="font-bold text-gray-900 dark:text-white">{getLocalized(service.name)}</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[11px]">Target Department</span>
                  <span className="font-bold text-gray-900 dark:text-white">{getLocalized(service.department)}</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[11px]">College</span>
                  <span className="font-bold text-gray-900 dark:text-white">{collegeName}</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[11px]">Family Income</span>
                  <span className="font-bold text-gray-900 dark:text-white">{annualIncome}</span>
                </div>
              </div>
            </div>

            {/* Declaration Checkbox */}
            <div className="flex items-start gap-3 p-3.5 rounded-xl bg-blue-50/50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900 text-xs text-blue-900 dark:text-blue-200">
              <input
                id="declaration"
                type="checkbox"
                defaultChecked
                className="mt-0.5 rounded text-blue-600 focus:ring-blue-500"
              />
              <label htmlFor="declaration">
                I hereby declare that all information furnished is true to the best of my knowledge. I understand that this is preliminary guidance and final eligibility is decided by the concerned welfare department.
              </label>
            </div>
          </div>
        )}

        {/* Wizard Controls */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
          {currentStep > 1 ? (
            <button
              type="button"
              onClick={() => setCurrentStep((prev) => prev - 1)}
              className="px-5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-xs sm:text-sm font-semibold text-gray-700 dark:text-gray-300 hover:bg-gray-50"
            >
              Previous Step
            </button>
          ) : (
            <div />
          )}

          {currentStep < 4 ? (
            <button
              type="button"
              onClick={() => setCurrentStep((prev) => prev + 1)}
              className="touch-target px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-sm transition-colors flex items-center gap-2"
            >
              <span>Next: {steps[currentStep].title}</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>
          ) : (
            <button
              type="button"
              disabled={isSubmitting}
              onClick={handleSubmitApplication}
              className="touch-target px-7 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-sm shadow-md transition-colors flex items-center gap-2"
            >
              <Send className="w-4 h-4" aria-hidden="true" />
              <span>{isSubmitting ? 'Submitting...' : 'Submit Application Now'}</span>
            </button>
          )}
        </div>
      </div>

      <FloatingAIAssistant currentService={service} contextStage={`Step ${currentStep} of Guided Application`} />
    </main>
  );
};
