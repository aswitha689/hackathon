import React from 'react';
import { HomeHero } from '../components/HomeHero';
import { CategoryCards } from '../components/CategoryCards';
import { QuickTrackCard } from '../components/QuickTrackCard';

export const HomePage: React.FC = () => {
  return (
    <main id="main-content" className="flex-1 flex flex-col">
      <HomeHero />
      <QuickTrackCard />
      <CategoryCards />
    </main>
  );
};
