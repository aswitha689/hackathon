import React from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  CheckCircle2,
  Copy,
  ArrowRight,
} from 'lucide-react';
import { getApplicationById } from '../utils/storage';
import { FloatingAIAssistant } from '../components/FloatingAIAssistant';

export const SubmissionSuccessPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const application = id ? getApplicationById(id) : undefined;
  const appId = id || 'SV-2026-001247';

  const [copied, setCopied] = React.useState(false);

  const handleCopyId = () => {
    navigator.clipboard.writeText(appId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <main id="main-content" className="flex-1 py-10 px-4 sm:px-6 max-w-3xl mx-auto w-full">
      <div className="bg-white dark:bg-gray-800 rounded-3xl border border-gray-200 dark:border-gray-700 p-8 sm:p-10 shadow-lg text-center card-accessible space-y-6">
        {/* Celebration Header */}
        <div className="flex flex-col items-center space-y-3">
          <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/70 text-emerald-600 dark:text-emerald-400 flex items-center justify-center animate-bounce">
            <CheckCircle2 className="w-10 h-10" aria-hidden="true" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white">
            Application Submitted 🎉
          </h1>
          <p className="text-sm text-gray-600 dark:text-gray-300 max-w-md">
            Your citizen service application has been successfully logged with the Welfare Department.
          </p>
        </div>

        {/* Generated Application ID Box */}
        <div className="p-5 rounded-2xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-900 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 dark:text-blue-300 block">
              Official Reference ID
            </span>
            <span className="text-2xl font-black tracking-tight text-blue-950 dark:text-blue-100">
              {appId}
            </span>
          </div>

          <button
            type="button"
            onClick={handleCopyId}
            aria-label="Copy tracking reference ID"
            className="touch-target px-4 py-2 rounded-xl bg-white dark:bg-gray-800 border border-blue-300 dark:border-blue-800 text-blue-700 dark:text-blue-300 text-xs font-bold hover:bg-blue-100/50 transition-colors flex items-center gap-1.5 shadow-2xs"
          >
            <Copy className="w-4 h-4" aria-hidden="true" />
            <span>{copied ? 'Copied!' : 'Copy ID'}</span>
          </button>
        </div>

        {/* Application Details Summary */}
        <div className="border border-gray-200 dark:border-gray-700 rounded-2xl p-5 text-left text-xs sm:text-sm space-y-3 bg-gray-50/50 dark:bg-gray-900/40">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <span className="text-gray-400 text-[11px] block">Citizen Applicant</span>
              <span className="font-bold text-gray-900 dark:text-white">
                {application?.citizenName || 'Anitha'}
              </span>
            </div>
            <div>
              <span className="text-gray-400 text-[11px] block">Service Scheme</span>
              <span className="font-bold text-gray-900 dark:text-white">
                {application?.serviceName || 'Post-Matric Scholarship & Fee Reimbursement'}
              </span>
            </div>
            <div>
              <span className="text-gray-400 text-[11px] block">Submission Date</span>
              <span className="font-bold text-gray-900 dark:text-white">
                {application?.submissionDate || 'Today, Just now'}
              </span>
            </div>
            <div>
              <span className="text-gray-400 text-[11px] block">Current Status</span>
              <span className="inline-flex items-center gap-1 font-bold text-emerald-600 dark:text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                <span>Submitted</span>
              </span>
            </div>
            <div className="sm:col-span-2">
              <span className="text-gray-400 text-[11px] block">Concerned Department</span>
              <span className="font-bold text-gray-900 dark:text-white">
                {application?.department || 'Department of Higher Education & Social Welfare'}
              </span>
            </div>
            <div className="sm:col-span-2">
              <span className="text-gray-400 text-[11px] block">Next Processing Stage</span>
              <span className="font-semibold text-blue-600 dark:text-blue-400">
                Documents Received → Desk Verification by Welfare Officer
              </span>
            </div>
          </div>
        </div>

        {/* Action Button: Track Application */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            type="button"
            onClick={() => navigate(`/track?id=${encodeURIComponent(appId)}`)}
            className="touch-target w-full sm:w-auto px-8 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition-colors flex items-center justify-center gap-2"
          >
            <span>Track Application Live</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </button>

          <Link
            to="/"
            className="touch-target w-full sm:w-auto px-6 py-3.5 rounded-xl border border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-200 font-semibold text-sm transition-colors text-center"
          >
            Return to Home
          </Link>
        </div>
      </div>

      <FloatingAIAssistant contextStage="Application Submitted" />
    </main>
  );
};
