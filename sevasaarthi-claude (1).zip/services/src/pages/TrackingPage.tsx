import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Search,
  CheckCircle2,
  Clock,
  FileCheck2,
  AlertCircle,
  Bell,
} from 'lucide-react';
import {
  getApplicationById,
  getCitizenNotifications,
  markNotificationsAsRead,
} from '../utils/storage';
import { FloatingAIAssistant } from '../components/FloatingAIAssistant';
import type { ApplicationRecord } from '../types';

export const TrackingPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialId = searchParams.get('id') || 'SV-2026-001247'; // Default Anitha demo ID

  const [searchId, setSearchId] = useState(initialId);
  const [activeApp, setActiveApp] = useState<ApplicationRecord | undefined>(() =>
    getApplicationById(initialId)
  );

  const [notifications, setNotifications] = useState(getCitizenNotifications());

  useEffect(() => {
    if (initialId) {
      const app = getApplicationById(initialId);
      setActiveApp(app);
      setSearchId(initialId);
    }
  }, [initialId]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId.trim()) return;
    setSearchParams({ id: searchId.trim().toUpperCase() });
    const found = getApplicationById(searchId.trim());
    setActiveApp(found);
  };

  // 5 Stages of the vertical timeline as specified
  const stages = [
    {
      key: 'Submitted',
      title: '1. Application Submitted',
      plainExplanation: 'Your details and preliminary eligibility declarations were successfully registered in the digital portal.',
      defaultTime: 'Step completed instantly upon submission',
    },
    {
      key: 'Documents Received',
      title: '2. Documents Received',
      plainExplanation: 'All required documents (bonafide letter, income certificate, marksheet) have been verified by the intake team.',
      defaultTime: 'Verified within 1–2 business days',
    },
    {
      key: 'Department Review',
      title: '3. Department Review',
      plainExplanation: 'The Welfare Officer is conducting field and institutional verification for tuition reimbursement sanction.',
      defaultTime: 'Typically takes 7–10 working days',
    },
    {
      key: 'Decision',
      title: '4. Decision / Sanction Order',
      plainExplanation: 'Final approval from District Social Welfare Officer; sanction letter and scholarship grant allotment generated.',
      defaultTime: 'Formal sanction generated',
    },
    {
      key: 'Completed',
      title: '5. Direct Benefit Credit (Completed)',
      plainExplanation: 'Tuition fees disbursed directly to the college account and student maintenance allowance transferred via DBT.',
      defaultTime: 'Credited to registered bank account',
    },
  ];

  const getStageStatus = (stageKey: string) => {
    if (!activeApp) return 'pending';
    const order = ['Submitted', 'Documents Received', 'Department Review', 'Decision', 'Completed'];
    const currentIndex = order.indexOf(activeApp.status);
    const stageIndex = order.indexOf(stageKey);

    if (stageIndex < currentIndex) return 'completed';
    if (stageIndex === currentIndex) return 'current';
    return 'pending';
  };

  return (
    <main id="main-content" className="flex-1 py-8 px-4 sm:px-6 max-w-4xl mx-auto w-full">
      {/* Top Search & Lookup bar */}
      <div className="mb-8 p-6 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm card-accessible space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
              Track Your Application
            </h1>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Clear, transparent updates on your citizen service request without government jargon.
            </p>
          </div>

          {/* Quick Anitha switch */}
          <button
            type="button"
            onClick={() => {
              setSearchId('SV-2026-001247');
              setSearchParams({ id: 'SV-2026-001247' });
              setActiveApp(getApplicationById('SV-2026-001247'));
            }}
            className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900 self-start sm:self-auto hover:bg-blue-100"
          >
            Load Anitha Demo (SV-2026-001247)
          </button>
        </div>

        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" aria-hidden="true" />
            <input
              type="text"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              placeholder="Enter Application ID, e.g. SV-2026-001247"
              aria-label="Enter Application ID"
              className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 text-sm font-semibold focus:border-blue-600 focus:outline-hidden"
            />
          </div>
          <button
            type="submit"
            className="touch-target px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-sm transition-colors"
          >
            Track Status
          </button>
        </form>
      </div>

      {/* Citizen Notification Alert from Admin (if any) */}
      {notifications.length > 0 && (
        <div className="mb-6 p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900 flex items-start gap-3">
          <Bell className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5 animate-bounce" aria-hidden="true" />
          <div className="flex-1 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-indigo-950 dark:text-indigo-200">
                Department Notification Received
              </span>
              <button
                type="button"
                onClick={() => {
                  markNotificationsAsRead();
                  setNotifications([]);
                }}
                className="text-[10px] text-indigo-600 dark:text-indigo-400 underline font-semibold"
              >
                Mark as read
              </button>
            </div>
            <p className="text-indigo-900 dark:text-indigo-300 mt-0.5">
              {notifications[0].message}
            </p>
          </div>
        </div>
      )}

      {/* Application Found Details */}
      {activeApp ? (
        <div className="space-y-6">
          {/* Header Card */}
          <div className="p-6 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm card-accessible">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 dark:border-gray-700/60 pb-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 block mb-0.5">
                  Reference: {activeApp.id}
                </span>
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                  {activeApp.serviceName}
                </h2>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                  {activeApp.department}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">Live Status:</span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-600 animate-ping" />
                  <span>{activeApp.status}</span>
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 text-xs">
              <div>
                <span className="text-gray-400 block">Applicant</span>
                <span className="font-bold text-gray-800 dark:text-gray-200">{activeApp.citizenName}</span>
              </div>
              <div>
                <span className="text-gray-400 block">Submitted On</span>
                <span className="font-bold text-gray-800 dark:text-gray-200">{activeApp.submissionDate}</span>
              </div>
              <div>
                <span className="text-gray-400 block">Registered State</span>
                <span className="font-bold text-gray-800 dark:text-gray-200">{activeApp.state}</span>
              </div>
              <div>
                <span className="text-gray-400 block">Last Activity</span>
                <span className="font-bold text-gray-800 dark:text-gray-200">{activeApp.lastUpdated}</span>
              </div>
            </div>
          </div>

          {/* Vertical Tracking Timeline */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm card-accessible">
            <h3 className="text-base font-bold text-gray-900 dark:text-white mb-6">
              Application Progress Timeline
            </h3>

            <div className="relative pl-6 border-l-2 border-gray-200 dark:border-gray-700 space-y-8 ml-3">
              {stages.map((stage) => {
                const status = getStageStatus(stage.key);

                return (
                  <div key={stage.key} className="relative group">
                    {/* Circle Node Icon */}
                    <div
                      className={`absolute -left-[35px] top-0 w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all ${
                        status === 'completed'
                          ? 'bg-emerald-600 border-emerald-600 text-white'
                          : status === 'current'
                          ? 'bg-blue-600 border-blue-600 text-white ring-4 ring-blue-100 dark:ring-blue-900/50'
                          : 'bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-400'
                      }`}
                    >
                      {status === 'completed' ? (
                        <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                      ) : status === 'current' ? (
                        <Clock className="w-4 h-4 animate-spin" aria-hidden="true" />
                      ) : (
                        <span className="w-2 h-2 rounded-full bg-gray-300 dark:bg-gray-600" />
                      )}
                    </div>

                    {/* Step Content */}
                    <div className="space-y-1">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                        <h4
                          className={`text-sm sm:text-base font-bold ${
                            status === 'current'
                              ? 'text-blue-600 dark:text-blue-400'
                              : status === 'completed'
                              ? 'text-gray-900 dark:text-white'
                              : 'text-gray-400 dark:text-gray-500'
                          }`}
                        >
                          {stage.title}
                        </h4>

                        <span className="text-[11px] font-semibold text-gray-400">
                          {status === 'completed'
                            ? 'Completed'
                            : status === 'current'
                            ? 'In Progress'
                            : 'Upcoming'}
                        </span>
                      </div>

                      <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed max-w-xl">
                        {stage.plainExplanation}
                      </p>

                      <span className="inline-block text-[11px] text-gray-400 font-medium pt-0.5">
                        Est: {stage.defaultTime}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Attached Verified Documents Section */}
          <div className="p-6 rounded-3xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm card-accessible space-y-4">
            <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <FileCheck2 className="w-5 h-5 text-blue-600" aria-hidden="true" />
              <span>Verified Application Documents ({activeApp.uploadedDocuments.length})</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {activeApp.uploadedDocuments.map((doc, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl bg-gray-50 dark:bg-gray-900/40 border border-gray-200 dark:border-gray-700 flex items-center justify-between text-xs"
                >
                  <div className="truncate pr-2">
                    <span className="font-bold text-gray-800 dark:text-gray-200 block truncate">
                      {doc.docName}
                    </span>
                    <span className="text-[11px] text-gray-400">{doc.fileName}</span>
                  </div>
                  <span className="shrink-0 px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-semibold text-[10px]">
                    Verified
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="p-8 text-center bg-white dark:bg-gray-800 rounded-3xl border border-gray-200 dark:border-gray-700 shadow-sm space-y-3">
          <AlertCircle className="w-10 h-10 text-amber-500 mx-auto" aria-hidden="true" />
          <h2 className="text-lg font-bold text-gray-900 dark:text-white">
            No Application Found with ID: "{searchId}"
          </h2>
          <p className="text-xs text-gray-500 max-w-sm mx-auto">
            Please check the reference number or try loading the default Anitha persona record.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchId('SV-2026-001247');
              setActiveApp(getApplicationById('SV-2026-001247'));
            }}
            className="px-4 py-2 rounded-xl bg-blue-600 text-white font-semibold text-xs"
          >
            Load Anitha Demo ID (SV-2026-001247)
          </button>
        </div>
      )}

      <FloatingAIAssistant contextStage="Application Tracking" />
    </main>
  );
};
