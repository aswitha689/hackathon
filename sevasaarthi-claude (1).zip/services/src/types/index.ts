export type Language = 'en' | 'te' | 'hi';

export type ServiceCategory =
  | 'education'
  | 'housing'
  | 'financial-assistance'
  | 'senior-citizens'
  | 'disability-services'
  | 'farmer-services'
  | 'certificates';

export interface LocalizedString {
  en: string;
  te: string;
  hi: string;
}

export interface EligibilityCriterion {
  id: string;
  question: LocalizedString;
  type: 'select' | 'number' | 'boolean';
  options?: { value: string; label: LocalizedString }[];
  helperText?: LocalizedString;
  validationRule?: {
    field: string;
    operator: 'eq' | 'lte' | 'gte' | 'in';
    targetValue: string | number | string[];
  };
}

export interface ServiceDocument {
  id: string;
  name: LocalizedString;
  required: boolean;
  description: LocalizedString;
  sampleName?: string;
}

export interface ServiceStep {
  stepNumber: number;
  title: LocalizedString;
  description: LocalizedString;
}

export interface ServiceFAQ {
  question: LocalizedString;
  answer: LocalizedString;
}

export interface Service {
  id: string;
  name: LocalizedString;
  category: ServiceCategory;
  description: LocalizedString;
  department: LocalizedString;
  stateOrRegion: string;
  isDemoData: boolean;
  matchKeywords: string[];
  eligibilitySummary: LocalizedString;
  criteria: EligibilityCriterion[];
  documents: ServiceDocument[];
  applicationSteps: ServiceStep[];
  processingInformation: {
    timeEstimate: LocalizedString;
    fees: LocalizedString;
    authority: LocalizedString;
  };
  officialSource: string;
  faq: ServiceFAQ[];
}

export type TextSize = 'normal' | 'large' | 'xlarge';
export type ContrastMode = 'default' | 'high' | 'dark';

export interface AccessibilitySettings {
  textSize: TextSize;
  contrastMode: ContrastMode;
  reduceMotion: boolean;
  simplifiedInterface: boolean;
  readAloudEnabled: boolean;
  dataSaver: boolean;
}

export interface ApplicationRecord {
  id: string; // SV-2026-XXXXXX
  serviceId: string;
  serviceName: string;
  citizenName: string;
  phone: string;
  age: number;
  state: string;
  status: 'Submitted' | 'Documents Received' | 'Department Review' | 'Decision' | 'Completed';
  submissionDate: string;
  lastUpdated: string;
  uploadedDocuments: { docId: string; docName: string; fileName: string; uploadTime: string }[];
  notes?: string[];
  department: string;
}
