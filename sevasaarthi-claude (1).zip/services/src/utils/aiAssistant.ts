import type { Service, Language } from '../types';

export interface AssistantResponse {
  answer: string;
  suggestedFollowUps?: string[];
  source?: 'llm' | 'rule';
}

/**
 * High-precision offline rule/keyword fallback matcher
 */
export const askAssistantOffline = (
  userMessage: string,
  service?: Service | null,
  language: Language = 'en',
  _currentContext?: string
): AssistantResponse => {
  const query = (userMessage || '').toLowerCase().trim();

  // If user asks in Telugu or asks "explain in Telugu"
  if (query.includes('telugu') || query.includes('తెలుగు') || language === 'te') {
    if (query.includes('document') || query.includes('పత్రాలు') || query.includes('కావాలి') || query.includes('docs')) {
      if (service) {
        const docNames = service.documents
          .map((d, i) => `${i + 1}. ${d.name.te} (${d.required ? 'తప్పనిసరి' : 'ఐచ్ఛికం'})`)
          .join('\n');
        return {
          answer: `ఈ పథకానికి క్రింది ధృవపత్రాలు అవసరం:\n\n${docNames}\n\nపత్రాలు స్పష్టమైన ఫోటో లేదా PDF రూపంలో ఉండాలి.\n\nగమనిక: ఇది ప్రాథమిక మార్గదర్శకత్వం మాత్రమే. తుది అర్హతను సంబంధిత అధికారులు నిర్ణయిస్తారు.`,
          suggestedFollowUps: ['నాకు అర్హత ఉందా?', 'తదుపరి ఏమి జరుగుతుంది?'],
          source: 'rule',
        };
      }
      return {
        answer: 'సాధారణంగా విద్యార్థి ఐడీ, ఆదాయ ధృవీకరణ పత్రం, మార్కుల జాబితా మరియు బ్యాంక్ పాస్‌బుక్ అవసరం.',
        suggestedFollowUps: ['స్కాలర్‌షిప్ పథకం చూడండి'],
        source: 'rule',
      };
    }

    if (query.includes('eligible') || query.includes('అర్హత') || query.includes('ఎవరు')) {
      if (service) {
        return {
          answer: `ప్రాథమిక అర్హత:\n${service.eligibilitySummary.te}\n\nగమనిక: ఇది ప్రాథమిక సమాచారం మాత్రమే. తుది అర్హతను సంబంధిత అధికారులు నిర్ణయిస్తారు.`,
          suggestedFollowUps: ['ఏ డాక్యుమెంట్లు కావాలి?', 'దరఖాస్తు విధానం ఏమిటి?'],
          source: 'rule',
        };
      }
    }

    if (query.includes('next') || query.includes('తరువాత') || query.includes('ఎప్పుడు')) {
      return {
        answer: `దరఖాస్తు సమర్పించిన తర్వాత:\n1. రిఫరెన్స్ ఐడీ (ఉదా: SV-2026-XXXXXX) వస్తుంది.\n2. సంబంధిత శాఖ 15-21 పనిదినాలలో మీ దరఖాస్తును పరిశీలిస్తుంది.\n3. మీరు 'దరఖాస్తు స్థితి' పేజీలో ఎప్పటికప్పుడు తెలుసుకోవచ్చు.`,
        suggestedFollowUps: ['అప్లికేషన్ ఎలా ట్రాక్ చేయాలి?'],
        source: 'rule',
      };
    }

    if (query.includes('చేయి') || query.includes('కాలు') || query.includes('ప్రమాదం') || query.includes('యాక్సిడెంట్') || query.includes('దివ్యాంగులు') || query.includes('వికలాంగులు')) {
      return {
        answer: `ప్రమాదంలో గాయపడిన లేదా అవయవాలు కోల్పోయిన పౌరులకు 'దివ్యాంగుల పింఛను & సహాయక పరికరాల పథకం' అందుబాటులో ఉంది:\n\n1. **వైద్య ధృవీకరణ:** జిల్లా ప్రభుత్వ ఆసుపత్రిలోని మెడికల్ బోర్డు ద్వారా సదరం (SADAREM) లేదా UDID సర్టిఫికేట్ పొందాలి (కనీసం 40% వైకల్యం ఉండాలి).\n2. **ఉచిత కృత్రిమ అవయవాలు:** ప్రభుత్వం మరియు ALIMCO ద్వారా ఉచితంగా కృత్రిమ చేతులు, కాళ్లు, లేదా వీల్‌చైర్లు అందజేస్తారు.\n3. **నెలవారీ పింఛను:** నెలకు ₹3,000 నుండి ₹6,000 వరకు నేరుగా బ్యాంక్ ఖాతాలో జమ అవుతుంది.\n4. **కావలసిన పత్రాలు:** ఆసుపత్రి చికిత్స నివేదిక/FIR, సదరం/UDID సర్టిఫికేట్, ఆధార్ కార్డు, బ్యాంక్ పాస్‌బుక్.\n\n*గమనిక: ఇది ప్రాథమిక మార్గదర్శకత్వం మాత్రమే. తుది అర్హతను సంబంధిత అధికారులు నిర్ణయిస్తారు.*`,
        suggestedFollowUps: ['ఏ డాక్యుమెంట్లు కావాలి?', 'నాకు అర్హత ఉందా?', 'దరఖాస్తు విధానం ఏమిటి?'],
        source: 'rule',
      };
    }

    if (service) {
      return {
        answer: `నమస్కారం! నేను మీ సేవాసారథి సహాయకుడిని. ${service.name.te} గురించి మీరు ఏవైనా ప్రశ్నలు అడగవచ్చు. ఉదాహరణకు: 'ఏ పత్రాలు కావాలి?', 'నాకు అర్హత ఉందా?'.`,
        suggestedFollowUps: ['ఏ పత్రాలు కావాలి?', 'నాకు అర్హత ఉందా?', 'తదుపరి ఏమి జరుగుతుంది?'],
        source: 'rule',
      };
    }
  }

  // Accident, Limb Loss, and Disability queries
  if (
    query.includes('hand') ||
    query.includes('accident') ||
    query.includes('leg') ||
    query.includes('arm') ||
    query.includes('limb') ||
    query.includes('disability') ||
    query.includes('disabled') ||
    query.includes('divyang') ||
    query.includes('amput')
  ) {
    return {
      answer: `For citizens who have experienced an accident, limb loss, or permanent physical injury, the government provides the **Divyangjan Disability Pension & Assistive Aid Scheme**:\n\n1. **Medical Assessment:** Undergo an assessment at the District Medical Board / Government Hospital to obtain a SADAREM or UDID Disability Certificate (minimum 40% disability required).\n2. **Free Assistive Devices & Artificial Limbs:** Free custom-fitted prosthetic hands/limbs, wheelchairs, or tricycles are distributed through ALIMCO and welfare camps.\n3. **Monthly Financial Pension:** Regular pension of ₹3,000 to ₹6,000/month credited directly via DBT to your bank account.\n4. **Essential Documents:** Hospital discharge/FIR report, Medical board assessment, Aadhaar card, and Bank passbook.\n\n*Disclaimer: This is preliminary guidance. Final eligibility is decided by the concerned authority.*`,
      suggestedFollowUps: [
        'What documents do I need?',
        'How to get UDID certificate?',
        'Explain in Telugu',
      ],
      source: 'rule',
    };
  }

  // English & Hindi responses
  if (query.includes('document') || query.includes('docs') || query.includes('dastavej')) {
    if (service) {
      const docList = service.documents
        .map((d, i) => `${i + 1}. ${d.name.en} [${d.required ? 'Mandatory' : 'Optional'}] - ${d.description.en}`)
        .join('\n');
      return {
        answer: `Here are the official required documents for ${service.name.en}:\n\n${docList}\n\n*Note: Digital clear scans or PDFs under 5MB are accepted.*\n\n*Disclaimer: This is preliminary guidance. Final eligibility is decided by the concerned authority.*`,
        suggestedFollowUps: ['Am I eligible?', 'Why do I need the income certificate?', 'What happens next?'],
        source: 'rule',
      };
    }
    return {
      answer: 'Standard citizen services usually require: 1. Identity proof, 2. Residence proof, 3. Income certificate, and 4. Bank passbook.',
      suggestedFollowUps: ['Check post-matric scholarship', 'Check income certificate'],
      source: 'rule',
    };
  }

  if (query.includes('eligible') || query.includes('patrata') || query.includes('who can apply')) {
    if (service) {
      return {
        answer: `**Preliminary Eligibility for ${service.name.en}:**\n${service.eligibilitySummary.en}\n\n*Important: This is preliminary guidance. Final eligibility is decided by the concerned authority (${service.processingInformation.authority.en}).*`,
        suggestedFollowUps: ['What documents do I need?', 'How long does processing take?'],
        source: 'rule',
      };
    }
  }

  if (query.includes('why') && (query.includes('income') || query.includes('document') || query.includes('bonafide'))) {
    return {
      answer: `**Why this document is required:**\n• **Bonafide / Admission letter:** Proves active enrollment in an authorized educational institution.\n• **Income Certificate:** Mandated by state welfare norms to verify household income stays under the limit for financial grants.`,
      suggestedFollowUps: ['What documents do I need?', 'What happens next?'],
      source: 'rule',
    };
  }

  if (query.includes('next') || query.includes('after submit') || query.includes('process') || query.includes('timeline')) {
    if (service) {
      return {
        answer: `**What happens next:**\n1. You will receive an instant Tracking ID (e.g. SV-2026-001247).\n2. Processing estimate is **${service.processingInformation.timeEstimate.en}** with **₹0 fee**.\n3. The ${service.department.en} will verify your uploaded documents.\n4. You can track real-time progress on the Track Application page.`,
        suggestedFollowUps: ['Can I edit after submitting?', 'Explain in Telugu'],
        source: 'rule',
      };
    }
    return {
      answer: 'After submitting, your application moves through Document Verification, Department Review, and Final Decision stages.',
      suggestedFollowUps: ['Track my application', 'Explain in Telugu'],
      source: 'rule',
    };
  }

  if (service) {
    return {
      answer: `Hello! I am your SevaSaarthi citizen navigator. For **${service.name.en}**, I can help you with:\n• Checking your preliminary eligibility\n• Required document checklist\n• Step-by-step application guidance\n• Timeline and next steps.\n\n*This is preliminary guidance. Final eligibility is decided by the concerned authority.*`,
      suggestedFollowUps: ['What documents do I need?', 'Am I eligible?', 'What happens next?', 'Explain in Telugu'],
      source: 'rule',
    };
  }

  return {
    answer: `Hello! I can guide you to find government services, verify documents, and track applications. Try asking:\n• "What documents do I need for college fees?"\n• "Am I eligible for scholarship?"\n• "Explain in Telugu"\n\n*This is preliminary guidance. Final eligibility is decided by the concerned authority.*`,
    suggestedFollowUps: [
      'What documents do I need for college fees?',
      'Am I eligible for student scholarship?',
      'Explain in Telugu',
    ],
    source: 'rule',
  };
};

export interface ChatTurn {
  role: 'user' | 'assistant';
  content: string;
}

/**
 * Main assistant entry point:
 * Calls the server-side /api/assistant (Claude via OpenRouter, grounded on services.json) first.
 * Falls back to the offline keyword assistant if the server is unreachable, slow,
 * the API key is missing, or credits run out, so the demo never breaks.
 */
export const askAssistant = async (
  userMessage: string,
  service?: Service | null,
  language: Language = 'en',
  currentContext?: string,
  history: ChatTurn[] = []
): Promise<AssistantResponse> => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 25000);
  try {
    const response = await fetch('/api/assistant', {
      method: 'POST',
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: userMessage,
        language,
        serviceId: service?.id,
        contextStage: currentContext,
        history,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (!data.fallback && data.answer) {
        return {
          answer: data.answer,
          suggestedFollowUps: data.suggestedFollowUps,
          source: 'llm',
        };
      }
    }
  } catch (err) {
    console.debug('Server LLM endpoint unavailable, using offline assistant rule engine.', err);
  } finally {
    clearTimeout(timer);
  }

  return askAssistantOffline(userMessage, service, language, currentContext);
};

/** Asks the server whether the Claude key is configured (used for the header badge). */
export const getAssistantStatus = async (): Promise<{ configured: boolean; model: string } | null> => {
  try {
    const res = await fetch('/api/assistant-status');
    return res.ok ? await res.json() : null;
  } catch {
    return null;
  }
};
