import rawServices from '../data/services.json';
import type { Service, ServiceCategory } from '../types';

const services = rawServices as unknown as Service[];

export interface MatchResult {
  service: Service;
  score: number;
  matchReason: {
    en: string;
    te: string;
    hi: string;
  };
}

export interface IntentDetection {
  detectedCategory: ServiceCategory | null;
  detectedIntentTitle: {
    en: string;
    te: string;
    hi: string;
  };
  matches: MatchResult[];
}

export const CATEGORY_NAMES: Record<ServiceCategory, { en: string; te: string; hi: string; emoji: string }> = {
  'disability-services': {
    en: '♿ Disability Support & Accident Relief Services',
    te: '♿ దివ్యాంగుల పింఛను & ప్రమాద సహాయ సేవలు',
    hi: '♿ दिव्यांगजन सहायता और दुर्घटना राहत',
    emoji: '♿',
  },
  education: {
    en: '🎓 Education & Scholarship Assistance',
    te: '🎓 విద్యా మరియు స్కాలర్‌షిప్ సహాయం',
    hi: '🎓 शिक्षा और छात्रवृत्ति सहायता',
    emoji: '🎓',
  },
  'senior-citizens': {
    en: '👴 Senior Citizens Pension & Welfare',
    te: '👴 వయోవృద్ధుల పింఛను & సంక్షేమం',
    hi: '👴 वरिष्ठ नागरिक पेंशन और कल्याण',
    emoji: '👴',
  },
  'farmer-services': {
    en: '🌾 Farmer Agriculture & Crop Grants',
    te: '🌾 రైతు వ్యవసాయం & పంట సహాయం',
    hi: '🌾 किसान कृषि और फसल सहायता',
    emoji: '🌾',
  },
  housing: {
    en: '🏠 Housing & Shelter Schemes',
    te: '🏠 గృహ వసతి & ఇళ్ల నిర్మాణ పథకాలు',
    hi: '🏠 आवास और पक्का मकान योजनाएं',
    emoji: '🏠',
  },
  certificates: {
    en: '📄 Official Certificates & Verification',
    te: '📄 అధికారిక ధృవీకరణ పత్రాలు',
    hi: '📄 आधिकारिक प्रमाण पत्र',
    emoji: '📄',
  },
  'financial-assistance': {
    en: '💰 Financial & Grant Assistance',
    te: '💰 ఆర్థిక సహాయం & నిధులు',
    hi: '💰 वित्तीय सहायता और अनुदान',
    emoji: '💰',
  },
};

// Common stop words to exclude from individual word matching
const STOP_WORDS = new Set([
  'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'you', 'your', 'yours',
  'he', 'him', 'his', 'she', 'her', 'it', 'its', 'they', 'them', 'their',
  'what', 'which', 'who', 'whom', 'this', 'that', 'these', 'those',
  'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had',
  'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or',
  'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about',
  'against', 'between', 'into', 'through', 'during', 'before', 'after',
  'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off',
  'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there',
  'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more',
  'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
  'so', 'than', 'too', 'very', 'can', 'will', 'just', 'should', 'now', 'need', 'want'
]);

// Generic words ("help", "support", "money"...) that appear inside keywords of MANY schemes.
// They may still count as part of a full phrase, but never as a lone word match,
// otherwise "help for my son's accident" drags in every scheme that says "help".
const GENERIC_WORDS = new Set([
  'help', 'helps', 'support', 'assistance', 'aid', 'scheme', 'schemes', 'service', 'services',
  'money', 'benefit', 'benefits', 'apply', 'application', 'government', 'govt', 'free',
  'సహాయం', 'సాయం', 'సహాయము', 'పథకం', 'పథకాలు', 'డబ్బు', 'ప్రభుత్వ', 'ప్రభుత్వం', 'దరఖాస్తు', 'ఉచితం', 'ఉచిత',
  'सहायता', 'मदद', 'योजना', 'योजनाएं', 'पैसा', 'पैसे', 'सरकारी', 'सरकार', 'आवेदन', 'मुफ्त', 'लाभ',
  // Telugu/Hindi filler words
  'కొడుకు', 'కూతురు', 'నాకు', 'నా', 'ఏం', 'ఏమి', 'దొరుకుతుంది', 'కావాలి', 'మేरा', 'मेरा', 'मेरे', 'बेटा', 'बेटी', 'क्या', 'मिलेगा', 'चाहिए',
]);

// High-confidence domain intent triggers
const DOMAIN_TRIGGERS: Array<{
  category: ServiceCategory;
  phrases: string[];
}> = [
  {
    category: 'disability-services',
    phrases: [
      'lost hand', 'lost leg', 'lost arm', 'lost limb', 'amputation', 'amputee',
      'accident', 'hand', 'leg', 'arm', 'limb', 'injured', 'injury', 'trauma',
      'disability', 'disabled', 'divyang', 'divyangjan', 'handicap', 'handicapped',
      'physically challenged', 'artificial limb', 'prosthetic', 'caliper', 'wheelchair',
      'tricycle', 'sadarem', 'udid', 'blind', 'deaf', 'paralysis', 'locomotor',
      'చేయి', 'కాలు', 'ప్రమాదం', 'యాక్సిడెంట్', 'దివ్యాంగులు', 'వికలాంగులు', 'అంగవైకల్యం', 'సదరం',
      'हाथ', 'पैर', 'दुर्घटना', 'एक्सीडेंट', 'दिव्यांग', 'विकलांग', 'अंग', 'चोट', 'यूडीआईडी'
    ],
  },
  {
    category: 'education',
    phrases: [
      'scholarship', 'college fee', 'college fees', 'tuition', 'student', 'degree',
      'diploma', 'btech', 'admission', 'exam fee', 'study', 'studying', 'school fee',
      'fee reimbursement', 'post matric', 'post-matric', 'anitha',
      'చదువు', 'స్కాలర్‌షిప్', 'కాలేజ్ ఫీజు', 'కాలేజీ', 'విద్యార్థి', 'డిగ్రీ', 'ఫీజు రీయింబర్స్‌మెంట్',
      'छात्रवृत्ति', 'कॉलेज फीस', 'पढ़ाई', 'छात्र', 'शुल्क', 'डिग्री'
    ],
  },
  {
    category: 'senior-citizens',
    phrases: [
      'senior citizen', 'senior citizens', 'elderly', 'old age', 'old people', 'pension',
      'retiree', 'retired', '60 years', 'aasara', 'grandparents',
      'వయోవృద్ధులు', 'ముసలివాళ్ళు', 'పెన్షన్', 'పింఛను', 'ఆసరా', 'వృద్ధాప్య',
      'वरिष्ठ नागरिक', 'बुजुर्ग', 'वृद्धावस्था', 'पेंशन', 'आसरा'
    ],
  },
  {
    category: 'farmer-services',
    phrases: [
      'farmer', 'farming', 'agriculture', 'crop', 'crops', 'cultivation', 'seed', 'seeds',
      'fertilizer', 'rythu', 'pattadar', 'pahani', 'landholding', 'harvest', 'irrigation',
      'రైతు', 'వ్యవసాయం', 'పంట', 'విత్తనాలు', 'సాగు', 'భూమి', 'రైతు భరోసా',
      'किसान', 'कृषि', 'फसल', 'खेती', 'बीज', 'खाद'
    ],
  },
  {
    category: 'housing',
    phrases: [
      'housing', 'house', 'home', 'pucca house', 'kutcha', 'roof', 'shelter', 'homeless',
      'awas', 'pmay', 'patta', 'plot allotment', 'colony', 'construction',
      'ఇల్లు', 'గృహం', 'ఇళ్ల స్థలం', 'పక్కా ఇల్లు', 'నివాసం', 'ఆవాస్',
      'मकान', 'घर', 'आवास', 'पक्का घर', 'छत', 'बेघर', 'पीएम आवास'
    ],
  },
  {
    category: 'certificates',
    phrases: [
      'income certificate', 'caste certificate', 'residence certificate', 'certificate',
      'meeseva', 'tahsildar', 'revenue officer', 'salary certificate', 'income proof',
      'ఆదాయ ధృవీకరణ', 'సర్టిఫికేట్', 'మీసేవ', 'తహసీల్దార్', 'రెవెన్యూ',
      'आय प्रमाण पत्र', 'सर्टिफिकेट', 'तहसील', 'प्रमाण पत्र', 'राजस्व'
    ],
  },
  {
    category: 'financial-assistance',
    phrases: [
      'financial aid', 'financial grant', 'financial assistance', 'cash assistance',
      'money assistance', 'stipend', 'grant money', 'book grant', 'hostel allowance',
      'డబ్బు సహాయం', 'ఆర్థిక సహాయం', 'గ్రాంట్',
      'आर्थिक सहायता', 'नकद सहायता', 'अनुदान'
    ],
  },
];

export const matchServices = (query: string, categoryFilter?: string | null): IntentDetection => {
  const normalizedQuery = (query || '').toLowerCase().trim();

  // 1. Direct Category Filter
  if (categoryFilter && categoryFilter in CATEGORY_NAMES) {
    const cat = categoryFilter as ServiceCategory;
    const filtered = services.filter((s) => s.category === cat);
    return {
      detectedCategory: cat,
      detectedIntentTitle: CATEGORY_NAMES[cat],
      matches: filtered.map((service) => ({
        service,
        score: 10,
        matchReason: {
          en: `Selected via the ${CATEGORY_NAMES[cat].en} category.`,
          te: `${CATEGORY_NAMES[cat].te} వర్గం ద్వారా ఎంపిక చేయబడింది.`,
          hi: `${CATEGORY_NAMES[cat].hi} श्रेणी के अंतर्गत चयनित।`,
        },
      })),
    };
  }

  // If query is empty, return empty
  if (!normalizedQuery) {
    return {
      detectedCategory: null,
      detectedIntentTitle: {
        en: '🔍 All Citizen Services',
        te: '🔍 అన్ని ప్రజా సేవలు',
        hi: '🔍 सभी नागरिक सेवाएं',
      },
      matches: services.slice(0, 3).map((service) => ({
        service,
        score: 1,
        matchReason: {
          en: 'Popular government welfare service.',
          te: 'ప్రజాదరణ పొందిన ప్రభుత్వ సంక్షేమ పథకం.',
          hi: 'लोकप्रिय सरकारी कल्याणकारी योजना।',
        },
      })),
    };
  }

  // 2. Detect Domain Intent based on triggers
  const detectedCategoryCounts = new Map<ServiceCategory, number>();
  for (const domain of DOMAIN_TRIGGERS) {
    for (const phrase of domain.phrases) {
      if (normalizedQuery.includes(phrase)) {
        // Multi-word phrase match gives higher weight
        const weight = phrase.includes(' ') ? 4 : 2;
        const current = detectedCategoryCounts.get(domain.category) || 0;
        detectedCategoryCounts.set(domain.category, current + weight);
      }
    }
  }

  let dominantCategory: ServiceCategory | null = null;
  let maxDomainWeight = 0;
  for (const [cat, weight] of detectedCategoryCounts.entries()) {
    if (weight > maxDomainWeight) {
      maxDomainWeight = weight;
      dominantCategory = cat;
    }
  }

  // Tokenize meaningful words (min length 3, not in STOP_WORDS)
  const words = normalizedQuery
    .split(/[\s,.;:!?()-]+/)
    .filter((w) => w.length >= 3 && !STOP_WORDS.has(w) && !GENERIC_WORDS.has(w));

  // 3. Score Each Service
  const scored = services.map((service) => {
    let score = 0;

    // Strong category intent boost
    if (dominantCategory && service.category === dominantCategory) {
      score += maxDomainWeight * 15;
    }

    // Exact title match in any language
    if (
      service.name.en.toLowerCase().includes(normalizedQuery) ||
      service.name.te.toLowerCase().includes(normalizedQuery) ||
      service.name.hi.toLowerCase().includes(normalizedQuery)
    ) {
      score += 40;
    }

    // Keyword match (whole phrase or exact word)
    for (const kw of service.matchKeywords) {
      const lowerKw = kw.toLowerCase();
      // Whole query includes the keyword phrase
      if (normalizedQuery.includes(lowerKw)) {
        score += lowerKw.includes(' ') ? 25 : 15;
      } else {
        // Word token match with word boundaries
        for (const word of words) {
          if (lowerKw === word) {
            score += 10;
          } else if (lowerKw.split(/\s+/).includes(word)) {
            score += 8;
          }
        }
      }
    }

    // Description match
    if (
      service.description.en.toLowerCase().includes(normalizedQuery) ||
      service.description.te.toLowerCase().includes(normalizedQuery) ||
      service.description.hi.toLowerCase().includes(normalizedQuery)
    ) {
      score += 10;
    }

    // Context-sensitive match reasoning
    let reasonEn = 'Matches your described citizen needs and preliminary eligibility criteria.';
    let reasonTe = 'మీరు తెలిపిన అవసరాలు మరియు ప్రాథమిక అర్హతలతో సరిపోలింది.';
    let reasonHi = 'आपकी बताई गई आवश्यकताओं और प्रारंभिक पात्रता से मेल खाता है।';

    if (service.category === 'disability-services') {
      reasonEn = 'Matches your inquiry regarding accidental injury, limb loss, and disability welfare pension.';
      reasonTe = 'ప్రమాదం వల్ల జరిగిన వైకల్య సహాయం, కృత్రిమ అవయవాలు మరియు దివ్యాంగుల పింఛను అవసరాలకు సరిపోలింది.';
      reasonHi = 'दुर्घटना जनित दिव्यांगता, कृत्रिम अंग सहायता और दिव्यांगजन पेंशन की आवश्यकता से मेल खाता है।';
    } else if (service.category === 'education') {
      reasonEn = 'Directly matches your need for college education fees, scholarships, and student aid.';
      reasonTe = 'కళాశాల విద్యా ఫీజులు, స్కాలర్‌షిప్‌లు మరియు విద్యార్థి ఆర్థిక సహాయం అవసరానికి సరిపోలింది.';
      reasonHi = 'कॉलेज शिक्षा शुल्क, छात्रवृत्ति और छात्र वित्तीय सहायता की आपकी आवश्यकता से सीधे मेल खाता है।';
    } else if (service.category === 'senior-citizens') {
      reasonEn = 'Matches monthly social security pension support for elderly senior citizens.';
      reasonTe = 'వయోవృద్ధులకు నెలవారీ సామాజిక భద్రతా పింఛను సహాయానికి సరిపోలింది.';
      reasonHi = 'वरिष्ठ नागरिकों के लिए मासिक सामाजिक सुरक्षा पेंशन से मेल खाता है।';
    } else if (service.category === 'farmer-services') {
      reasonEn = 'Matches agricultural crop investment aid and seed subsidy for cultivating farmers.';
      reasonTe = 'రైతులకు పంట పెట్టుబడి మరియు ఎరువుల సహాయ పథకానికి సరిపోలింది.';
      reasonHi = 'किसानों के लिए फसल निवेश सहायता और बीज सब्सिडी से मेल खाता है।';
    } else if (service.category === 'housing') {
      reasonEn = 'Matches affordable housing subsidies and permanent pucca house construction grants.';
      reasonTe = 'శాశ్వత పక్కా ఇళ్ల నిర్మాణం మరియు గృహ వసతి సహాయానికి సరిపోలింది.';
      reasonHi = 'पक्के मकान के निर्माण और आवास सब्सिडी सहायता से मेल खाता है।';
    } else if (service.category === 'certificates') {
      reasonEn = 'Provides the official revenue certificate required for welfare schemes and fee reimbursement.';
      reasonTe = 'సంక్షేమ పథకాలు మరియు ఫీజు రీయింబర్స్‌మెంట్ కోసం అవసరమైన అధికారిక ఆదాయ పత్రం.';
      reasonHi = 'कल्याणकारी योजनाओं और शुल्क प्रतिपूर्ति के लिए आवश्यक आधिकारिक राजस्व प्रमाण पत्र।';
    } else if (service.category === 'financial-assistance') {
      reasonEn = 'Matches direct financial grant and student living allowance support.';
      reasonTe = 'ప్రత్యక్ష ఆర్థిక గ్రాంట్ మరియు విద్యా ఖర్చుల సహాయానికి సరిపోలింది.';
      reasonHi = 'सीधी वित्तीय सहायता और निर्वाह भत्ता से मेल खाता है।';
    }

    return {
      service,
      score,
      matchReason: {
        en: reasonEn,
        te: reasonTe,
        hi: reasonHi,
      },
    };
  });

  // Filter matched services (must have positive score > 0)
  let matched = scored.filter((s) => s.score > 0).sort((a, b) => b.score - a.score);

  // Relevance cutoff: keep only results that are genuinely close to the best match.
  // When the intent is clear (e.g. accident / limb loss), other categories are dropped
  // unless they scored at least half as well as the top result.
  if (matched.length > 1) {
    const top = matched[0].score;
    const strongIntent = dominantCategory !== null && maxDomainWeight >= 2;
    matched = matched.filter((m, i) => {
      if (i === 0) return true;
      // Sibling schemes in the winning category are always relevant
      if (dominantCategory && m.service.category === dominantCategory) return true;
      if (strongIntent) return m.score >= top * 0.5;
      return m.score >= top * 0.35;
    });
  }

  // 4. If No Match Found: HONEST ZERO-MATCH (Never fake education!)
  if (matched.length === 0) {
    return {
      detectedCategory: null,
      detectedIntentTitle: {
        en: '🔍 No Direct Scheme Matched',
        te: '🔍 మీ శోధనకు సరిపోలే పథకం లభించలేదు',
        hi: '🔍 कोई सीधा मेल नहीं मिला',
      },
      matches: [],
    };
  }

  const topCategory = dominantCategory || matched[0].service.category;

  return {
    detectedCategory: topCategory,
    detectedIntentTitle: CATEGORY_NAMES[topCategory] || {
      en: '🔍 Relevant Government Services',
      te: '🔍 సంబంధిత ప్రభుత్వ సేవలు',
      hi: '🔍 संबंधित सरकारी सेवाएं',
    },
    matches: matched.slice(0, 3), // Return 2-3 matched service cards
  };
};
