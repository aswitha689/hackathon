import type { ApplicationRecord } from '../types';
import { supabase, isSupabaseConfigured } from './supabase';

const STORAGE_KEY = 'sevasaarthi_applications';
const NOTIFICATIONS_KEY = 'sevasaarthi_notifications';
export const NOTIFICATION_EVENT = 'sevasaarthi_notification_update';

export interface CitizenNotification {
  id: string;
  applicationId: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
}

export const SEEDED_DEMO_APPLICATIONS: ApplicationRecord[] = [
  {
    id: 'SV-2026-001247',
    serviceId: 'post-matric-scholarship',
    serviceName: 'Post-Matric Scholarship & Fee Reimbursement',
    citizenName: 'Anitha',
    phone: '9876543210',
    age: 20,
    state: 'Andhra Pradesh',
    status: 'Documents Received',
    submissionDate: '2026-10-01 10:30 AM',
    lastUpdated: '2026-10-02 03:15 PM',
    uploadedDocuments: [
      {
        docId: 'doc_college_id',
        docName: 'College Bonafide / Admission Allotment Letter',
        fileName: 'anitha_bonafide_2026.pdf',
        uploadTime: '2026-10-01 10:28 AM',
      },
      {
        docId: 'doc_income_cert',
        docName: 'Income Certificate (MeeSeva / Tehsil)',
        fileName: 'income_cert_2026.pdf',
        uploadTime: '2026-10-01 10:29 AM',
      },
      {
        docId: 'doc_marksheet',
        docName: 'Previous Qualifying Marksheet (10th/Inter)',
        fileName: 'inter_marksheet_gradeA.pdf',
        uploadTime: '2026-10-01 10:29 AM',
      },
      {
        docId: 'doc_bank_passbook',
        docName: 'Student Bank Passbook Copy',
        fileName: 'bank_passbook_sbi.pdf',
        uploadTime: '2026-10-01 10:30 AM',
      },
    ],
    department: 'Department of Higher Education & Social Welfare',
    notes: ['All preliminary documents verified online by ePASS portal.'],
  },
  {
    id: 'SV-2026-003891',
    serviceId: 'senior-citizen-pension',
    serviceName: 'Senior Citizen Social Security Pension (Aasara)',
    citizenName: 'Lakshmi Devi',
    phone: '9440123456',
    age: 64,
    state: 'Telangana',
    status: 'Department Review',
    submissionDate: '2026-09-28 11:15 AM',
    lastUpdated: '2026-10-01 02:20 PM',
    uploadedDocuments: [
      {
        docId: 'doc_age_proof',
        docName: 'Age Proof (Aadhaar or Voter ID)',
        fileName: 'lakshmi_voter_card.pdf',
        uploadTime: '2026-09-28 11:10 AM',
      },
      {
        docId: 'doc_ration_card',
        docName: 'Ration Card (White / BPL)',
        fileName: 'white_ration_card.pdf',
        uploadTime: '2026-09-28 11:12 AM',
      },
    ],
    department: 'Department of Social Security and Rural Development',
    notes: ['Local Panchayat Secretary completed residence verification.'],
  },
  {
    id: 'SV-2026-004512',
    serviceId: 'rythu-bharosa-farmer-aid',
    serviceName: 'Rythu Farmer Input Assistance & Crop Grant',
    citizenName: 'Ramesh Kumar',
    phone: '9848011223',
    age: 46,
    state: 'Andhra Pradesh',
    status: 'Completed',
    submissionDate: '2026-09-20 09:45 AM',
    lastUpdated: '2026-10-02 11:00 AM',
    uploadedDocuments: [
      {
        docId: 'doc_pattadar_passbook',
        docName: 'Pattadar Land Passbook / Pahani Copy',
        fileName: 'pahani_survey_88_2.pdf',
        uploadTime: '2026-09-20 09:40 AM',
      },
      {
        docId: 'doc_bank_passbook',
        docName: 'Farmer Bank Passbook (Aadhaar linked)',
        fileName: 'apgb_passbook.pdf',
        uploadTime: '2026-09-20 09:42 AM',
      },
    ],
    department: 'Department of Agriculture & Cooperation',
    notes: ['Disbursement of ₹7,500 credited via DBT to APGB account.'],
  },
  {
    id: 'SV-2026-005629',
    serviceId: 'income-certificate',
    serviceName: 'Official Income Certificate Issuance',
    citizenName: 'Rajesh Sharma',
    phone: '9701044556',
    age: 28,
    state: 'Telangana',
    status: 'Decision',
    submissionDate: '2026-10-02 04:10 PM',
    lastUpdated: '2026-10-03 09:30 AM',
    uploadedDocuments: [
      {
        docId: 'doc_address_proof',
        docName: 'Address & Residence Proof',
        fileName: 'electricity_bill.pdf',
        uploadTime: '2026-10-02 04:05 PM',
      },
      {
        docId: 'doc_salary_or_affidavit',
        docName: 'Salary Slip / Self Declaration',
        fileName: 'notary_affidavit.pdf',
        uploadTime: '2026-10-02 04:08 PM',
      },
    ],
    department: 'Revenue Department (Tahsildar / MeeSeva)',
    notes: ['Revenue Inspector signed digital certificate. Awaiting Tahsildar e-sign.'],
  },
  {
    id: 'SV-2026-006103',
    serviceId: 'vidya-deevena-support',
    serviceName: 'Higher Education Financial Assistance & Book Grant',
    citizenName: 'Priya Verma',
    phone: '9866122334',
    age: 19,
    state: 'Andhra Pradesh',
    status: 'Submitted',
    submissionDate: '2026-10-03 01:20 PM',
    lastUpdated: '2026-10-03 01:20 PM',
    uploadedDocuments: [
      {
        docId: 'doc_college_id',
        docName: 'Student Identity Card',
        fileName: 'priya_id_card.pdf',
        uploadTime: '2026-10-03 01:18 PM',
      },
    ],
    department: 'Department of Collegiate Education',
    notes: ['Initial registration logged online.'],
  },
];

const DEFAULT_NOTIFICATIONS: CitizenNotification[] = [
  {
    id: 'notif_init_1',
    applicationId: 'SV-2026-001247',
    title: 'Documents Verified (Demo)',
    message: 'ePASS verification desk confirmed your College Bonafide and Income certificate for SV-2026-001247.',
    timestamp: '2 hours ago',
    read: false,
  },
  {
    id: 'notif_init_2',
    applicationId: 'SV-2026-001247',
    title: 'Desk Forwarding',
    message: 'Application SV-2026-001247 scheduled for District Social Welfare Officer sanction review.',
    timestamp: 'Yesterday',
    read: false,
  },
];

export const getStoredApplications = (): ApplicationRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(SEEDED_DEMO_APPLICATIONS));
      return SEEDED_DEMO_APPLICATIONS;
    }
    const apps: ApplicationRecord[] = JSON.parse(raw);
    for (const seed of SEEDED_DEMO_APPLICATIONS) {
      if (!apps.some((a) => a.id === seed.id)) {
        apps.push(seed);
      }
    }
    return apps;
  } catch (e) {
    console.error('Failed to load applications from localStorage', e);
    return SEEDED_DEMO_APPLICATIONS;
  }
};

export const getApplicationById = (id: string): ApplicationRecord | undefined => {
  const apps = getStoredApplications();
  return apps.find((a) => a.id.trim().toUpperCase() === id.trim().toUpperCase());
};

export const saveApplication = async (app: ApplicationRecord): Promise<void> => {
  try {
    // 1. Save locally
    const apps = getStoredApplications();
    const existingIndex = apps.findIndex((a) => a.id === app.id);
    if (existingIndex >= 0) {
      apps[existingIndex] = app;
    } else {
      apps.unshift(app);
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(apps));

    // 2. Sync to Supabase if configured
    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('applications').upsert({
          id: app.id,
          service_id: app.serviceId,
          service_name: app.serviceName,
          citizen_name: app.citizenName,
          phone: app.phone,
          age: app.age,
          state: app.state,
          status: app.status,
          submission_date: app.submissionDate,
          last_updated: app.lastUpdated,
          uploaded_documents: app.uploadedDocuments,
          department: app.department,
          notes: app.notes || [],
        });
      } catch (err) {
        console.warn('Supabase application sync error:', err);
      }
    }
  } catch (e) {
    console.error('Failed to save application', e);
  }
};

export const updateApplicationStatus = async (
  id: string,
  newStatus: ApplicationRecord['status'],
  note?: string
): Promise<boolean> => {
  try {
    const apps = getStoredApplications();
    const index = apps.findIndex((a) => a.id.toUpperCase() === id.toUpperCase());
    if (index >= 0) {
      apps[index].status = newStatus;
      apps[index].lastUpdated = 'Just now';
      if (note) {
        if (!apps[index].notes) apps[index].notes = [];
        apps[index].notes!.push(note);
      }
      localStorage.setItem(STORAGE_KEY, JSON.stringify(apps));

      // Trigger automatic citizen notification!
      addCitizenNotification({
        applicationId: apps[index].id,
        title: `Department Status Updated: ${newStatus}`,
        message:
          note ||
          `Your application for ${apps[index].serviceName} has progressed to the "${newStatus}" stage.`,
      });

      // Sync status update to Supabase
      if (isSupabaseConfigured() && supabase) {
        try {
          await supabase
            .from('applications')
            .update({
              status: newStatus,
              last_updated: 'Just now',
              notes: apps[index].notes,
            })
            .eq('id', apps[index].id);
        } catch (err) {
          console.warn('Supabase status update error:', err);
        }
      }

      return true;
    }
    return false;
  } catch (e) {
    console.error('Failed to update status', e);
    return false;
  }
};

export const generateApplicationId = (): string => {
  const randomSuffix = Math.floor(100000 + Math.random() * 900000);
  return `SV-2026-${randomSuffix}`;
};

export const getCitizenNotifications = (): CitizenNotification[] => {
  try {
    const raw = localStorage.getItem(NOTIFICATIONS_KEY);
    if (!raw) {
      localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(DEFAULT_NOTIFICATIONS));
      return DEFAULT_NOTIFICATIONS;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_NOTIFICATIONS;
  }
};

export const addCitizenNotification = async (
  notif: Omit<CitizenNotification, 'id' | 'timestamp' | 'read'>
): Promise<void> => {
  try {
    const notifs = getCitizenNotifications();
    const newNotif: CitizenNotification = {
      ...notif,
      id: `notif_${Date.now()}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
    };
    notifs.unshift(newNotif);
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifs));
    window.dispatchEvent(new Event(NOTIFICATION_EVENT));

    // Sync to Supabase if available
    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('notifications').insert({
          id: newNotif.id,
          application_id: newNotif.applicationId,
          title: newNotif.title,
          message: newNotif.message,
          timestamp: newNotif.timestamp,
          read: newNotif.read,
        });
      } catch (err) {
        console.warn('Supabase notification sync error:', err);
      }
    }
  } catch (e) {
    console.error('Failed to add citizen notification', e);
  }
};

export const markNotificationsAsRead = async (): Promise<void> => {
  try {
    const notifs = getCitizenNotifications().map((n) => ({ ...n, read: true }));
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifs));
    window.dispatchEvent(new Event(NOTIFICATION_EVENT));

    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('notifications').update({ read: true }).eq('read', false);
      } catch (err) {
        console.warn('Supabase mark read error:', err);
      }
    }
  } catch (e) {
    console.error('Failed to mark notifications as read', e);
  }
};

export const clearNotifications = async (): Promise<void> => {
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify([]));
    window.dispatchEvent(new Event(NOTIFICATION_EVENT));

    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('notifications').delete().neq('id', 'dummy');
      } catch (err) {
        console.warn('Supabase clear notifications error:', err);
      }
    }
  } catch (e) {
    console.error('Failed to clear notifications', e);
  }
};
