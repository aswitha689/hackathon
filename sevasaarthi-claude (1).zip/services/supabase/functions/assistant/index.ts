// Supabase Edge Function: /functions/v1/assistant
// Deno runtime with CORS and Gemini LLM call

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { query, language = "en", serviceId, contextStage } = await req.json();
    const apiKey = Deno.env.get("GEMINI_API_KEY");

    if (!apiKey) {
      return new Response(
        JSON.stringify({ fallback: true, error: "GEMINI_API_KEY is not configured" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
      );
    }

    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

    const prompt = `You are SevaSaarthi, an accessible citizen service assistant.
Ground all answers ONLY in verified government schemes.
Preliminary guidance notice is required.
Citizen Query: "${query}"
Language: ${language}
Service ID: ${serviceId || "General"}
Stage: ${contextStage || "General"}
Provide a clear, helpful answer and 2 follow-up suggestions prefixed with SUGGESTIONS:`;

    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
      }),
    });

    const data = await res.json();
    const answer = data?.candidates?.[0]?.content?.parts?.[0]?.text || "Information not available.";

    return new Response(
      JSON.stringify({ answer, source: "llm" }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: any) {
    return new Response(
      JSON.stringify({ fallback: true, error: err.message }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
    );
  }
});
