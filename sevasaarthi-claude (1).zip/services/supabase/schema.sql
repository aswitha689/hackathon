-- ==============================================================================
-- SevaSaarthi: Government Services Navigator - Database Schema (Supabase)
-- Tables: users, services, applications, documents, notifications, faqs
-- ==============================================================================

-- Enable UUID extension if not enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. USERS TABLE (Optional Citizen Profiles)
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone VARCHAR(20),
  name VARCHAR(255),
  age INT,
  state VARCHAR(100),
  preferred_language VARCHAR(10) DEFAULT 'en',
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 2. SERVICES TABLE (Demo Schemes Knowledge Base)
CREATE TABLE IF NOT EXISTS public.services (
  id VARCHAR(100) PRIMARY KEY,
  name JSONB NOT NULL,
  category VARCHAR(50) NOT NULL,
  description JSONB NOT NULL,
  department JSONB NOT NULL,
  state_or_region VARCHAR(150),
  is_demo_data BOOLEAN DEFAULT true,
  match_keywords JSONB DEFAULT '[]'::jsonb,
  eligibility_summary JSONB NOT NULL,
  criteria JSONB DEFAULT '[]'::jsonb,
  documents JSONB DEFAULT '[]'::jsonb,
  application_steps JSONB DEFAULT '[]'::jsonb,
  processing_information JSONB NOT NULL,
  official_source TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 3. APPLICATIONS TABLE (Citizen Application Submissions)
CREATE TABLE IF NOT EXISTS public.applications (
  id VARCHAR(50) PRIMARY KEY, -- e.g. SV-2026-001247
  service_id VARCHAR(100) REFERENCES public.services(id) ON DELETE SET NULL,
  service_name TEXT NOT NULL,
  citizen_name VARCHAR(255) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  age INT NOT NULL,
  state VARCHAR(100) NOT NULL,
  status VARCHAR(50) DEFAULT 'Submitted',
  submission_date TEXT NOT NULL,
  last_updated TEXT NOT NULL,
  uploaded_documents JSONB DEFAULT '[]'::jsonb,
  department TEXT NOT NULL,
  notes JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 4. DOCUMENTS TABLE (Metadata & Upload Links)
CREATE TABLE IF NOT EXISTS public.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id VARCHAR(50) REFERENCES public.applications(id) ON DELETE CASCADE,
  doc_id VARCHAR(100) NOT NULL,
  doc_name TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_url TEXT,
  uploaded_at TIMESTAMPTZ DEFAULT now()
);

-- 5. NOTIFICATIONS TABLE (Real-time Citizen Alerts)
CREATE TABLE IF NOT EXISTS public.notifications (
  id VARCHAR(100) PRIMARY KEY,
  application_id VARCHAR(50),
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  timestamp TEXT NOT NULL,
  read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 6. FAQS TABLE (Knowledge Base FAQs)
CREATE TABLE IF NOT EXISTS public.faqs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id VARCHAR(100) REFERENCES public.services(id) ON DELETE CASCADE,
  question JSONB NOT NULL,
  answer JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ==============================================================================
-- Row Level Security (RLS) - Permissive for Hackathon Demo
-- ==============================================================================
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.faqs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read on services" ON public.services FOR SELECT USING (true);
CREATE POLICY "Allow public all on applications" ON public.applications FOR ALL USING (true);
CREATE POLICY "Allow public all on documents" ON public.documents FOR ALL USING (true);
CREATE POLICY "Allow public all on notifications" ON public.notifications FOR ALL USING (true);
CREATE POLICY "Allow public read on faqs" ON public.faqs FOR SELECT USING (true);
CREATE POLICY "Allow public all on users" ON public.users FOR ALL USING (true);

-- ==============================================================================
-- Seed Demo Data: Services
-- ==============================================================================
INSERT INTO public.services (
  id, name, category, description, department, state_or_region, is_demo_data,
  match_keywords, eligibility_summary, processing_information, official_source
) VALUES 
(
  'post-matric-scholarship',
  '{"en": "Post-Matric Scholarship & Fee Reimbursement", "te": "పోస్ట్-మెట్రిక్ స్కాలర్‌షిప్ & ఫీజు రీయింబర్స్‌మెంట్", "hi": "पोस्ट-मैट्रिक छात्रवृत्ति और शुल्क प्रतिपूर्ति"}'::jsonb,
  'education',
  '{"en": "Financial assistance for post-matriculation students pursuing diploma, graduate, and post-graduate college degrees.", "te": "డిప్లొమా, డిగ్రీ మరియు పీజీ చదువుతున్న విద్యార్థులకు ట్యూషన్ ఫీజుల రీయింబర్స్‌మెంట్.", "hi": "डिप्लोमा, स्नातक और स्नातकोत्तर कॉलेज की पढ़ाई करने वाले छात्रों के लिए ट्यूशन फीस प्रतिपूर्ति।"}'::jsonb,
  '{"en": "Department of Higher Education & Social Welfare", "te": "ఉన్నత విద్య & సాంఘిక సంక్షేమ శాఖ", "hi": "उच्च शिक्षा और समाज कल्याण विभाग"}'::jsonb,
  'Andhra Pradesh / Telangana (Demo Data)',
  true,
  '["scholarship", "education", "college fee", "student", "tuition", "anitha", "చదువు", "స్కాలర్‌షిప్", "కాలేజ్ ఫీజు", "छात्रवृत्ति", "पढ़ाई"]'::jsonb,
  '{"en": "Students aged 17–30 in recognized colleges with family annual income under ₹2.5 Lakhs.", "te": "గుర్తింపు పొందిన కళాశాలల్లో చేరిన 17-30 సంవత్సరాల విద్యార్థులు, ఆదాయం ₹2.5 లక్షల లోపు.", "hi": "मान्यता प्राप्त कॉलेज में नामांकित 17-30 वर्ष के छात्र, आय ₹2.5 लाख से कम।"}'::jsonb,
  '{"timeEstimate": {"en": "15 to 21 working days", "te": "15 నుండి 21 పనిదినాలు", "hi": "15 से 21 कार्य दिवस"}, "fees": {"en": "Free of Cost (₹0)", "te": "ఉచితం (₹0)", "hi": "निःशुल्क (₹0)"}, "authority": {"en": "District Social Welfare Officer", "te": "జిల్లా సాంఘిక సంక్షేమ అధికారి", "hi": "जिला समाज कल्याण अधिकारी"}}'::jsonb,
  'State ePASS Welfare Portal'
) ON CONFLICT (id) DO NOTHING;

-- Seed Demo Application for Anitha
INSERT INTO public.applications (
  id, service_id, service_name, citizen_name, phone, age, state, status,
  submission_date, last_updated, uploaded_documents, department, notes
) VALUES (
  'SV-2026-001247',
  'post-matric-scholarship',
  'Post-Matric Scholarship & Fee Reimbursement',
  'Anitha',
  '9876543210',
  20,
  'Andhra Pradesh',
  'Documents Received',
  '2026-10-01 10:30 AM',
  '2026-10-02 03:15 PM',
  '[{"docId": "doc_college_id", "docName": "College Bonafide Letter", "fileName": "anitha_bonafide_2026.pdf"}, {"docId": "doc_income_cert", "docName": "Income Certificate", "fileName": "income_cert_2026.pdf"}]'::jsonb,
  'Department of Higher Education & Social Welfare',
  '["All preliminary documents verified online by ePASS portal."]'::jsonb
) ON CONFLICT (id) DO NOTHING;

-- Seed Notification for Anitha
INSERT INTO public.notifications (
  id, application_id, title, message, timestamp, read
) VALUES (
  'notif_init_1',
  'SV-2026-001247',
  'Documents Verified (Demo)',
  'ePASS verification desk confirmed your College Bonafide and Income certificate for SV-2026-001247.',
  '2 hours ago',
  false
) ON CONFLICT (id) DO NOTHING;
