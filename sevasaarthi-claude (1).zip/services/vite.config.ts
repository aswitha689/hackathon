import { defineConfig, loadEnv, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { callServerLLM, getAssistantStatus } from './server/llmService.ts';

type Middlewares = { use: (path: string, fn: (req: any, res: any) => void) => void };

function mountAssistant(middlewares: Middlewares) {
  // GET /api/assistant-status -> lets the UI show whether Claude is connected
  middlewares.use('/api/assistant-status', (_req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(getAssistantStatus()));
  });

  middlewares.use('/api/assistant', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    if (req.method !== 'POST') {
      res.statusCode = 405;
      res.end(JSON.stringify({ error: 'Method Not Allowed' }));
      return;
    }
    let body = '';
    req.on('data', (chunk: Buffer) => {
      body += chunk;
      if (body.length > 20_000) req.destroy();
    });
    req.on('end', async () => {
      try {
        const result = await callServerLLM(JSON.parse(body || '{}'));
        res.statusCode = 200;
        res.end(JSON.stringify(result));
      } catch (err: any) {
        // Client seamlessly switches to the offline keyword assistant
        console.warn('[assistant] falling back:', err.message);
        res.statusCode = 200;
        res.end(JSON.stringify({ fallback: true, error: err.message }));
      }
    });
  });
}

function assistantServerPlugin(): Plugin {
  return {
    name: 'assistant-server-endpoint',
    configureServer(server) {
      mountAssistant(server.middlewares);
    },
    // also works with `npm run build && npm run preview` (stable demo mode)
    configurePreviewServer(server) {
      mountAssistant(server.middlewares);
    },
  };
}

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  // Load .env / .env.local values for the Node-side Vite dev middleware.
  // These values are never exposed through import.meta.env because the key
  // is intentionally NOT prefixed with VITE_.
  const env = loadEnv(mode, process.cwd(), '');
  Object.assign(process.env, env);

  return {
    plugins: [
      tailwindcss(),
      react(),
      assistantServerPlugin(),
    ],
  };
});
